/*
QuickCG

Copyright (c) 2004, Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

*) Redistributions of source code must retain the above copyright notice, this 
list of conditions and the following disclaimer.
*) Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <SDL/SDL.h>
#include <cstdlib>
#include <cmath>
#include "QuickCG.h"
using namespace std;

//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//GLOBAL VARIABLES//////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

SDL_Surface *scr; //the single SDL surface used
int w;
int h;
Uint8 *inkeys;

//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//BASIC SCREEN FUNCTIONS////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

//The screen function: sets up the window for 32-bit color graphics.
//Creates a graphical screen of width*height pixels in 32-bit color.
//Set fullscreen to 0 for a window, or to 1 for fullscreen output
//*text is the caption or title of the window
void screen(int width, int height, bool fullscreen, char *text)
{
    int colorDepth = 32;
    w = width;
    h = height;

    if(SDL_Init(SDL_INIT_VIDEO) < 0)
    {
       printf("Unable to init SDL: %s\n", SDL_GetError());
       SDL_Quit();
       exit(1);
    }
    atexit(SDL_Quit);
    if(fullscreen)
    {
        scr = SDL_SetVideoMode(width,height,colorDepth,SDL_SWSURFACE|SDL_FULLSCREEN);
        lock();
    }
    else
    {
        scr = SDL_SetVideoMode(width,height,colorDepth,SDL_HWSURFACE|SDL_HWPALETTE);
    }
    if(scr == NULL)
    {
        printf("Unable to set video: %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
    }
    SDL_WM_SetCaption(text, NULL);
}

//Locks the screen
void lock()
{
    if(SDL_MUSTLOCK(scr))
    if(SDL_LockSurface(scr) < 0)
    return;
}

//Unlocks the screen
void unlock()
{
    if(SDL_MUSTLOCK(scr))
    SDL_UnlockSurface(scr);
}

//Updates the screen.  Has to be called to view new pixels, but use only after
//drawing the whole screen because it's slow.
void redraw()
{
    SDL_UpdateRect(scr, 0, 0, 0, 0);
}

//Clears the screen to black
void cls(ColorRGB color)
{
    SDL_FillRect(scr, NULL, 65536 * color.r + 256 * color.g + color.b);
}

/*void pset(int x, int y, Uint8 R, Uint8 G, Uint8 b){}*/
//Puts an RGB color pixel at position x,y
void pset(int x, int y, ColorRGB color)
{
    Uint32 colorSDL = SDL_MapRGB(scr->format, color.r, color.g, color.b);
    Uint32 *bufp;
    bufp = (Uint32 *)scr->pixels + (y % h) * scr->pitch / 4 + x % w;
    *bufp = colorSDL;
}

//Gets RGB color of pixel at position x,y
ColorRGB pget(int x, int y)
{
    Uint32 *bufp;
    bufp = (Uint32 *)scr->pixels + (y % h) * scr->pitch / 4 + x % w;
    Uint32 colorSDL = *bufp;
    ColorRGB8bit colorRGB;
    SDL_GetRGB(colorSDL, scr->format, &colorRGB.r, &colorRGB.g, &colorRGB.b);
    return ColorRGB(colorRGB);
}

//Draws a buffer of pixels to the screen
void drawBuffer(Uint32 *buffer)
{
    Uint32 *bufp;
    bufp = (Uint32 *)scr->pixels;
    
    for(int y = 0; y < h; y++)
    {
        for(int x = 0; x < w; x++)
        {
             *bufp=buffer[h * x + y];
             bufp++;
        }
        bufp += scr->pitch / 4;
        bufp -= w;
    }        
}

bool onScreen(int x, int y)
{
    return (x >= 0 && y >= 0 && x < w && y < h);
}    



//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//NON GRAPHICAL FUNCTIONS///////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

//Waits until you press a key. First the key has to be loose, this means, if you put two sleep functions in a row, the second will only work after you first released the key.
void sleep()
{
    SDL_Event event;
    int done = 0;
    while(done == 0)
    {
        while(SDL_PollEvent(&event))
        {
            if(event.type == SDL_QUIT) end();
            if(event.type == SDL_KEYDOWN) done = 1;
        }
        SDL_Delay(5); //so it consumes less processing power
    }
}

void waitFrame(float oldTime, float mspf) //mspf = milliseconds per frame
{
    float time = getTime();
    while(time - oldTime < mspf)
    {
        time = getTime();
        SDL_Event event;        
        SDL_PollEvent(&event);
        if(event.type == SDL_QUIT) end();
        inkeys = SDL_GetKeyState(NULL);
        if(inkeys[SDLK_ESCAPE]) end();         
        SDL_Delay(5); //so it consumes less processing power      
    }   
}    

//Returns 1 if you close the window or press the escape key
//Never put key input code right before done() or SDL may see the key as SDL_QUIT
bool done()
{
    SDL_Event event;
    int done = 0;
    if(!SDL_PollEvent(&event)) return 0;
    inkeys = SDL_GetKeyState(NULL);
    if(inkeys[SDLK_ESCAPE]) done = 1;
    if(event.type == SDL_QUIT) done = 1;
    return done;
}

//Ends the program
void end()
{
    SDL_Quit();
    exit(1);
}

//Gives value of pressed key to inkeys.
//the variable inkeys can then be used anywhere to check for input
//Normally you have to use readkeys every time you want to use inkeys, but the done() function also uses inkeys so it's not needed to use readkeys if you use done().
void readKeys()
{
    inkeys = SDL_GetKeyState(NULL);
}

void getMouseState(int & mouseX, int & mouseY)
{
    SDL_GetMouseState(&mouseX, &mouseY);
             
}

void getMouseState(int & mouseX, int & mouseY, bool & LMB, bool & RMB)
{
    Uint8 mouseState = SDL_GetMouseState(&mouseX, &mouseY);
    
    if(mouseState & 1) LMB = true; 
    else LMB = false;
    if(mouseState & 4) RMB = true; 
    else RMB = false;            
}  

//Returns the time in milliseconds since the program started
float getTime()
{
    return SDL_GetTicks();
}


//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//2D SHAPES/////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//


//Fast horizontal line from (x1,y) to (x2,y), with rgb color
bool horLine(int y, int x1, int x2, ColorRGB color)
{
    if(x2 < x1) {x1 += x2; x2 = x1 - x2; x1 -= x2;} //swap x1 and x2, x1 must be the leftmost endpoint   
    if(x2 < 0 || x1 > w - 1 || y < 0 || y > h - 1) return 0; //no single point of the line is on screen
    
    if(x1 < 0) x1 = 0;
    if(x2 >= w) x2 = w - 1;
    
    Uint32 colorSDL = SDL_MapRGB(scr->format, color.r, color.g, color.b);
    Uint32 *bufp;
    bufp = (Uint32 *)scr->pixels + (y % h) * scr->pitch / 4 + x1 - 1;
    for(int x = x1; x <= x2; x++)
    {
        bufp++;
        *bufp = colorSDL;
    }
}


//Fast vertical line from (x,y1) to (x,y2), with rgb color
bool verLine(int x, int y1, int y2, ColorRGB color)
{
    if(y2 < y1) {y1 += y2; y2 = y1 - y2; y1 -= y2;} //swap y1 and y2
    if(x < 0 || x > w - 1 || y2 < 0 || y1 > h - 1) return 0;
    
    if(y1 < 0) y1 = 0;
    if(y2 >= h) y2 = h - 1;            
   
    Uint32 colorSDL = SDL_MapRGB(scr->format, color.r, color.g, color.b);
    Uint32 *bufp;
    bufp = (Uint32 *)scr->pixels + y1 * (scr->pitch / 4) + x % w - 1;
    for(int y = y1; y <= y2; y++)
    {
         bufp += scr->pitch / 4;
         *bufp = colorSDL;
    }    
    return 1;
}


//Bresenham line from (x1,y1) to (x2,y2) with rgb color
bool drawLine(int x1, int y1, int x2, int y2, ColorRGB color)
{
    if(x1 < 0 || x1 > w - 1 || x2 < 0 || x2 > w - 1 || y1 < 0 || y1 > h - 1 || y2 < 0 || y2 > h - 1) return 0;
    
    int deltax = abs(x2 - x1);        // The difference between the x's
    int deltay = abs(y2 - y1);        // The difference between the y's
    int x = x1;                     // Start x off at the first pixel
    int y = y1;                     // Start y off at the first pixel
    int xinc1, xinc2, yinc1, yinc2, den, num, numadd, numpixels, curpixel;

    if (x2 >= x1)                 // The x-values are increasing
    {
        xinc1 = 1;
        xinc2 = 1;
    }
    else                          // The x-values are decreasing
    {
        xinc1 = -1;
        xinc2 = -1;
    }
    if (y2 >= y1)                 // The y-values are increasing
    {
        yinc1 = 1;
        yinc2 = 1;
    }
    else                          // The y-values are decreasing
    {
        yinc1 = -1;
        yinc2 = -1;
    }
    if (deltax >= deltay)         // There is at least one x-value for every y-value
    {
        xinc1 = 0;                  // Don't change the x when numerator >= denominator
        yinc2 = 0;                  // Don't change the y for every iteration
        den = deltax;
        num = deltax / 2;
        numadd = deltay;
        numpixels = deltax;         // There are more x-values than y-values
    }
    else                          // There is at least one y-value for every x-value
    {
        xinc2 = 0;                  // Don't change the x for every iteration
        yinc1 = 0;                  // Don't change the y when numerator >= denominator
        den = deltay;
        num = deltay / 2;
        numadd = deltax;
        numpixels = deltay;         // There are more y-values than x-values
    }
    for (curpixel = 0; curpixel <= numpixels; curpixel++)
    {
        pset(x % w, y % h, color);  // Draw the current pixel
        num += numadd;              // Increase the numerator by the top of the fraction
        if (num >= den)           // Check if numerator >= denominator
        {
            num -= den;             // Calculate the new numerator value
            x += xinc1;             // Change the x as appropriate
            y += yinc1;             // Change the y as appropriate
        }
        x += xinc2;                 // Change the x as appropriate
        y += yinc2;                 // Change the y as appropriate
    }
    
    return 1;
}


//Bresenham circle with center at (xc,yc) with radius and red green blue color
bool drawCircle(int xc, int yc, int radius, ColorRGB color)
{
    if(xc - radius < 0 || xc + radius >= w || yc - radius < 0 || yc + radius >= h) return 0;
    int x = 0;
    int y = radius;
    int p = 3 - (radius << 1);
    int a, b, c, d, e, f, g, h;
    while (x <= y)
    {
         a = xc + x; //8 pixels can be calculated at once thanks to the symmetry
         b = yc + y;
         c = xc - x;
         d = yc - y;
         e = xc + y;
         f = yc + x;
         g = xc - y;
         h = yc - x;
         pset(a, b, color);
         pset(c, d, color);
         pset(e, f, color);
         pset(g, f, color);
         if(x>0) //avoid drawing pixels at same position as the other ones
         {
             pset(a, d, color);
             pset(c, b, color);
             pset(e, h, color);
             pset(g, h, color);
         }
         if(p < 0) p += (x++ << 2) + 6;
         else p += ((x++ - y--) << 2) + 10;
  }
  
  return 1;
}


//Filled bresenham circle with center at (xc,yc) with radius and red green blue color
bool drawDisk(int xc, int yc, int radius, ColorRGB color)
{
    if(xc + radius < 0 || xc - radius >= w || yc + radius < 0 || yc - radius >= h) return 0; //every single pixel outside screen, so don't waste time on it
    int x = 0;
    int y = radius;
    int p = 3 - (radius << 1);
    int a, b, c, d, e, f, g, h;
    int pb, pd; //previous values: to avoid drawing horizontal lines multiple times    
    while (x <= y)
    {
         // write data
         a = xc + x;
         b = yc + y;
         c = xc - x;
         d = yc - y;
         e = xc + y;
         f = yc + x;
         g = xc - y;
         h = yc - x;
         if(b != pb) horLine(b, a, c, color);
         if(d != pd) horLine(d, a, c, color);
         if(f != b)  horLine(f, e, g, color);
         if(h != d && h != f) horLine(h, e, g, color);
         pb = b;
         pd = d;         
         if(p < 0) p += (x++ << 2) + 6;
         else p += ((x++ - y--) << 2) + 10;
  }
  
  return 1;
}

//Rectangle with corners (x1,y1) and (x2,y2) and rgb color
bool drawRect(int x1, int y1, int x2, int y2, ColorRGB color)
{
    if(x1 < 0 || x1 > w - 1 || x2 < 0 || x2 > w - 1 || y1 < 0 || y1 > h - 1 || y2 < 0 || y2 > h - 1) return 0;
    SDL_Rect rec;
    rec.x = x1;
    rec.y = y1;
    rec.w = x2 - x1 + 1;
    rec.h = y2 - y1 + 1;
    Uint32 colorSDL = SDL_MapRGB(scr->format, color.r, color.g, color.b);
    SDL_FillRect(scr, &rec, colorSDL);  //SDL's ability to draw a hardware rectangle is used for now
    return 1;
}

//Functions for clipping a 2D line to the screen, which is the rectangle (0,0)-(w,h)
//This is the Cohen-Sutherland Clipping Algorithm
//Each of 9 regions gets an outcode, based on if it's at the top, bottom, left or right of the screen
// 1001 1000 1010    9 8 10
// 0001 0000 0010    1 0 2
// 0101 0100 0110    5 4 6
//int findregion returns which of the 9 regions a point is in, void clipline does the actual clipping
int findRegion(int x, int y)
{
    int code=0;
    if(y >= h)
    code |= 1; //top
    else if( y < 0)
    code |= 2; //bottom
    if(x >= w)
    code |= 4; //right
    else if ( x < 0)
    code |= 8; //left
    return(code);
}
bool clipLine(int x1, int y1, int x2, int y2, int & x3, int & y3, int & x4, int & y4)
{
    int code1, code2, codeout;
    bool accept = 0, done=0;
    code1 = findRegion(x1, y1); //the region outcodes for the endpoints
    code2 = findRegion(x2, y2);
    do  //In theory, this can never end up in an infinite loop, it'll always come in one of the trivial cases eventually
    {
        if(!(code1 | code2)) accept = done = 1;  //accept because both endpoints are in screen or on the border, trivial accept
        else if(code1 & code2) done = 1; //the line isn't visible on screen, trivial reject
        else  //if no trivial reject or accept, continue the loop
        {
            int x, y;
            codeout = code1 ? code1 : code2;
            if(codeout & 1) //top
            {
                x = x1 + (x2 - x1) * (h - y1) / (y2 - y1);
                y = h - 1;
            }
            else if(codeout & 2) //bottom
            {
                x = x1 + (x2 - x1) * -y1 / (y2 - y1);
                y = 0;
            }
            else if(codeout & 4) //right
            {
                y = y1 + (y2 - y1) * (w - x1) / (x2 - x1);
                x = w - 1;
            }
            else //left
            {
                y = y1 + (y2 - y1) * -x1 / (x2 - x1);
                x = 0;
            }
            if(codeout == code1) //first endpoint was clipped
            {
                x1 = x; y1 = y;
                code1 = findRegion(x1, y1);
            }
            else //second endpoint was clipped
            {
                x2 = x; y2 = y;
                code2 = findRegion(x2, y2);
            }
        }
    }
    while(done == 0);

    if(accept)
    {
        x3 = x1;
        x4 = x2;
        y3 = y1;
        y4 = y2;
        return 1;
    }
    else
    {
        x3 = x4 = y3 = y4 = 0;
        return 0;
    }
}


//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//COLOR STRUCTS/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//
ColorRGB::ColorRGB(Uint8 r, Uint8 g, Uint8 b)
{
    this->r = r;
    this->g = g;
    this->b = b;
}
ColorRGB::ColorRGB(ColorRGB8bit color)
{
    this->r = color.r;
    this->g = color.g;
    this->b = color.b;
}
ColorRGB::ColorRGB()
{
    this->r = 0;
    this->g = 0;
    this->b = 0;
}
ColorRGB8bit::ColorRGB8bit(Uint8 r, Uint8 g, Uint8 b)
{
    this->r = r;
    this->g = g;
    this->b = b;
}
ColorRGB8bit::ColorRGB8bit(ColorRGB color)
{
    this->r = color.r;
    this->g = color.g;
    this->b = color.b;
}
ColorRGB8bit::ColorRGB8bit()
{
    this->r = 0;
    this->g = 0;
    this->b = 0;
}

//Add two colors
ColorRGB operator+(ColorRGB color, ColorRGB color2)
{
    ColorRGB c;
    c.r = color.r + color2.r;
    c.g = color.g + color2.g;
    c.b = color.b + color2.b;
    return c;
}

//Subtract two colors
ColorRGB operator-(ColorRGB color, ColorRGB color2)
{
    ColorRGB c;
    c.r = color.r - color2.r;
    c.g = color.g - color2.g;
    c.b = color.b - color2.b;
    return c;
}

//Multiplies a color with an integer
ColorRGB operator*(ColorRGB color, int a)
{
    ColorRGB c;
    c.r = color.r * a;
    c.g = color.g * a;
    c.b = color.b * a;
    return c;
}

//Multiplies a color with an integer
ColorRGB operator*(int a, ColorRGB color)
{
    ColorRGB c;
    c.r = color.r * a;
    c.g = color.g * a;
    c.b = color.b * a;
    return c;
}

//Divides a color through an integer
ColorRGB operator/(ColorRGB color, int a)
{
    if(a == 0) return color;
    ColorRGB c;
    c.r = color.r / a;
    c.g = color.g / a;
    c.b = color.b / a;
    return c;
}

//Are both colors equal?
bool operator==(ColorRGB color, ColorRGB color2)
{
    return(color.r == color2.r && color.g == color2.g && color.b == color2.b);
}

//Are both colors not equal?
bool operator!=(ColorRGB color, ColorRGB color2)
{
    return(!(color.r == color2.r && color.g == color2.g && color.b == color2.b));
}

ColorHSL::ColorHSL(Uint8 h, Uint8 s, Uint8 l)
{
    this->h = h;
    this->s = s;
    this->l = l;
}
ColorHSL::ColorHSL()
{
    this->h = 0;
    this->s = 0;
    this->l = 0;
}
ColorHSV::ColorHSV(Uint8 h, Uint8 s, Uint8 v)
{
    this->h = h;
    this->s = s;
    this->v = v;
}
ColorHSV::ColorHSV()
{
    this->h = 0;
    this->s = 0;
    this->v = 0;
}


//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//COLOR CONVERSIONS/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

/*
Convert colors from one type to another
r=red  g=green  b=blue  h=hue  s=saturation  l=lightness  v=value
Color components from the color structs are Uint8's between 0 and 255
color components used in the calculations are normalized between 0.0-1.0
*/

//Converts an RGB color to HSL color
ColorHSL RGBtoHSL(ColorRGB colorRGB)
{
    float r, g, b, h, s, l; //this function works with floats between 0 and 1
    r = colorRGB.r / 256.0;
    g = colorRGB.g / 256.0;
    b = colorRGB.b / 256.0;

    float maxColor = max(r, max(g, b));
    float minColor = min(r, min(g, b));

    if(minColor == maxColor) //R = G = B, so it's a shade of grey
    {
        h = 0; //it doesn't matter what value it has
        s = 0;
        l = r; //doesn't matter if you pick r, g, or b
    }
    else
    {
        l = (minColor + maxColor) / 2;

        if(l < 0.5) s = (maxColor - minColor) / (maxColor + minColor);
        if(l >= 0.5) s = (maxColor - minColor) / (2.0 - maxColor - minColor);

        if(r == maxColor) h = (g - b) / (maxColor - minColor);
        if(g == maxColor) h = 2.0 + (b - r) / (maxColor - minColor);
        if(b == maxColor) h = 4.0 + (r - g) / (maxColor - minColor);

        h /= 6; //to bring it to a number between 0 and 1
        if(h < 0) h += 1;
    }
    
    ColorHSL colorHSL;
    colorHSL.h = int(h * 255.0);
    colorHSL.s = int(s * 255.0);
    colorHSL.l = int(l * 255.0);
    return colorHSL;
}

//Converts an HSL color to RGB color
ColorRGB HSLtoRGB(ColorHSL colorHSL)
{
    float r, g, b, h, s, l; //this function works with floats between 0 and 1
    float temp1, temp2, tempr, tempg, tempb;
    h = colorHSL.h / 256.0;
    s = colorHSL.s / 256.0;
    l = colorHSL.l / 256.0;

    //If saturation is 0, the color is a shade of grey
    if(s == 0) r = g = b = l;
    //If saturation > 0, more complex calculations are needed
    else
    {
        //set the temporary values
        if(l < 0.5) temp2 = l * (1 + s);
        else temp2 = (l + s) - (l * s);
        temp1 = 2 * l - temp2;
        tempr=h + 1.0 / 3.0;
        if(tempr > 1.0) tempr--;
        tempg=h;
        tempb=h-1.0 / 3.0;
        if(tempb < 0.0) tempb++;

        //red
        if(tempr < 1.0 / 6.0) r = temp1 + (temp2 - temp1) * 6.0 * tempr;
        else if(tempr < 0.5) r = temp2;
        else if(tempr < 2.0 / 3.0) r = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - tempr) * 6.0;
        else r = temp1;
      
         //green
        if(tempg < 1.0 / 6.0) g = temp1 + (temp2 - temp1) * 6.0 * tempg;
        else if(tempg < 0.5) g=temp2;
        else if(tempg < 2.0 / 3.0) g = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - tempg) * 6.0;
        else g = temp1;

        //blue
        if(tempb < 1.0 / 6.0) b = temp1 + (temp2 - temp1) * 6.0 * tempb;
        else if(tempb < 0.5) b = temp2;
        else if(tempb < 2.0 / 3.0) b = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - tempb) * 6.0;
        else b = temp1;
    }

    ColorRGB colorRGB;
    colorRGB.r = int(r * 255.0);
    colorRGB.g = int(g * 255.0);
    colorRGB.b = int(b * 255.0);
    return colorRGB;
}

//Converts an RGB color to HSV color
ColorHSV RGBtoHSV(ColorRGB colorRGB)
{
    float r, g, b, h, s, v; //this function works with floats between 0 and 1
    r = colorRGB.r / 256.0;
    g = colorRGB.g / 256.0;
    b = colorRGB.b / 256.0;

    float maxColor = max(r, max(g, b));
    float minColor = min(r, min(g, b));

    v = maxColor;

    if(maxColor == 0.0) //avoid division by zero when the color is black
    {
        s = 0.0;
    }
    else
    {
        s = (maxColor - minColor) / maxColor;
    }
    if(s == 0.0)
    {
        h = 0.0; //it doesn't matter what value it has
    }
    else
    {
        if(r == maxColor) h = (g - b) / (maxColor - minColor);
        if(g == maxColor) h = 2.0 + (b - r) / (maxColor - minColor);
        if(b == maxColor) h = 4.0 + (r - g) / (maxColor - minColor);

        h /= 6.0; //to bring it to a number between 0 and 1
        if(h < 0.0) h++;
    }

    ColorHSV colorHSV;
    colorHSV.h = int(h * 255.0);
    colorHSV.s = int(s * 255.0);
    colorHSV.v = int(v * 255.0);
    return colorHSV;
}

//Converts an HSV color to RGB color
ColorRGB HSVtoRGB(ColorHSV colorHSV)
{
    float r, g, b, h, s, v; //this function works with floats between 0 and 1
    h = colorHSV.h / 256.0;
    s = colorHSV.s / 256.0;
    v = colorHSV.v / 256.0;

    //if saturation is 0, the color is a shade of grey
    if(s == 0.0) r = g = b = v;
    //if saturation > 0, more complex calculations are needed
    else
    {
        float f, p, q, t;
        int i;
        h *= 6.0; //to bring hue to a number between 0 and 6, better for the calculations
        i = int(floor(h)); //e.g. 2.7 becomes 2 and 3.01 becomes 3 or 4.9999 becomes 4
        f = h - i;//the fractional part of h

        p = v * (1.0 - s);
        q = v * (1.0 - (s * f));
        t = v * (1.0 - (s * (1.0 - f)));

        switch(i)
        {
            case 0: r=v; g=t; b=p; break;
            case 1: r=q; g=v; b=p; break;
            case 2: r=p; g=v; b=t; break;
            case 3: r=p; g=q; b=v; break;
            case 4: r=t; g=p; b=v; break;
            case 5: r=v; g=p; b=q; break;
        }
    }
    ColorRGB colorRGB;
    colorRGB.r = int(r * 255.0);
    colorRGB.g = int(g * 255.0);
    colorRGB.b = int(b * 255.0);
    return colorRGB;
}



Uint32 RGBtoINT(ColorRGB colorRGB)
{
    return 65536 * colorRGB.r + 256 * colorRGB.g + colorRGB.b;
}    

ColorRGB INTtoRGB(Uint32 colorINT)
{
    ColorRGB colorRGB;
    colorRGB.r = (colorINT / 65536) % 256;
    colorRGB.g = (colorINT / 256) % 256;
    colorRGB.b = colorINT % 256;
    return colorRGB;
}    

//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//BMP FUNCTIONS/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

//Loads an RGB BMP into an array (call the function with a 2-dimensional array as the following example: "ColorRGB image[w][h]; loadBMP("flower.bmp", image[0], w, h);")
int loadBMP(char *filename, ColorRGB *image, int w, int h)
{
    SDL_Surface *img;
    
    //Fill the array with a pattern so that it contains something if the image doesn't exist  
    for(int x = 0; x < w; x++)
    for(int y = 0; y < h; y++)
    {
        image[h * x + y].r = 255 * font[((x + y) / 8) % 256][y % 8][x % 8];            
        image[h * x + y].g = 255 * font[((x + y)/ 8) % 256][(y + x) % 8][x % 8]; 
        image[h * x + y].b = 255 * font[((x)/ 8) % 256][y % 8][(x + y) % 8];
    } 

    if(!(img = SDL_LoadBMP(filename))) return 0; //load the image and return error if it doesn't exist 
    int bpp = img->format->BytesPerPixel;
    if(bpp < 3) return 0; //return error if the BMP isn't 24 bit color
    
    int smallestw, smallesth;
    
    if((img->w) < w) smallestw = (img->w); else smallestw = w;
    if((img->h) < h) smallesth = (img->h); else smallesth = h;
     
    for(int x = 0; x < smallestw; x++)
    for(int y = 0; y < smallesth; y++)
    {
        Uint8 *p = (Uint8 *)img->pixels + y * img->pitch + x * bpp;
        Uint32 colorSDL = *(Uint32 *)p;
        ColorRGB8bit color;
        SDL_GetRGB(colorSDL, img->format, &color.r, &color.g, &color.b);
        image[h * x + y] = color;
    }    
    SDL_FreeSurface(img);                  
}

//Loads an RGB BMP into an array (call the function with a 2-dimensional array as the following example: "char blab[w][h]; loadBMP("flower.bmp",blab[0],w,h);")
int loadBMP(char *filename, Uint32 *image, int w, int h)
{
    SDL_Surface *img;
    
    //Fill the array with a pattern so that it contains something if the image doesn't exist  
    for(int x = 0; x < w; x++)
    for(int y = 0; y < h; y++)
    {
        image[h * x + y] = 255 * font[((x + y) / 8) % 256][y % 8][x % 8];            
    } 

    if(!(img = SDL_LoadBMP(filename))) return 0; //load the image and return error if it doesn't exist 
    int bpp = img->format->BytesPerPixel;
    if(bpp < 3) return 0; //return error if the BMP isn't 24 bit color
    
    int smallestw, smallesth;
    
    if((img->w) < w) smallestw = (img->w); else smallestw = w;
    if((img->h) < h) smallesth = (img->h); else smallesth = h;
     
    for(int x = 0; x < smallestw; x++)
    for(int y = 0; y < smallesth; y++)
    {
        Uint8 *p = (Uint8 *)img->pixels + y * img->pitch + x * bpp;
        Uint32 color = *(Uint32 *)p;
        image[h * x + y] = color;            
    }    
    SDL_FreeSurface(img);                  
}

//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//TEXT FUNCTIONS////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

//Draws character n at position x,y with color RGB and, if enabled, background color
//This function is used by the text printing functions below, and uses the font data
//defined below to draw the letter pixel by pixel
static void inline drawLetter(unsigned char n, int x, int y, ColorRGB color, bool bg, ColorRGB color2)
{
    int u,v;

    for (v = 0; v < 8; v++)
    for (u = 0; u < 8; u++)
    {
        if(font[n][v][u]) pset(x + u, y + v, color);
        else if(bg) pset(x + u, y + v, color2);
    }
}

//Draws a string of text
int print(char *text, int x, int y, ColorRGB color, bool bg, ColorRGB color2, int forceLength)
{
  int pos = 0;
  while(text[pos])
  {
       drawLetter(text[pos], x, y, color, bg, color2);
       pos++;
       x += 8;
       if(x > w - 8) {x %= 8; y += 8;}
       if(y > h - 8) {y %= 8;}
  }
  if(forceLength > 0)
  {
      while(pos < forceLength)
      {
           drawLetter(0, x, y, color, bg, color2);
           pos++;
           x += 8;
           if(x > w - 8) {x %= 8; y += 8;}
           if(y > h - 8) {y %= 8;}
      }      
  }    
  //return pos;
  return h * x + y;
}

//Draws an integer number
int iprint(int a, int x, int y, ColorRGB color, bool bg, ColorRGB color2, bool orderSigns, int forceLength)
{
  char text[255];
  sprintf(text, "%i", a);
  int negationSymbol = 0;
  if(a >= 0 && orderSigns) negationSymbol = 8;
  return print(text, x + negationSymbol, y, color, bg, color2, forceLength);
}

//Draws an unsigned integer number
int iprint(Uint32 a, int x, int y, ColorRGB color, bool bg, ColorRGB color2, bool orderSigns, int forceLength)
{
  char text[255];
  sprintf(text, "%u", a);
  int negationSymbol = 0;
  if(a >= 0 && orderSigns) negationSymbol = 8;
  return print(text, x + negationSymbol, y, color, bg, color2, forceLength);
}

//Draws a floating point number
int fprint(double a, int length, int x, int y, ColorRGB color, bool bg, ColorRGB color2, bool orderSigns, int forceLength)
{
  char text[255];
  switch(length)
  {
      case 1: sprintf(text, "%.1f", a); break;
      case 2: sprintf(text, "%.2f", a); break;
      case 3: sprintf(text, "%.3f", a); break;
      case 4: sprintf(text, "%.4f", a); break;
      case 5: sprintf(text, "%.5f", a); break;
      case 6: sprintf(text, "%.6f", a); break;
      case 7: sprintf(text, "%.7f", a); break;
      case 8: sprintf(text, "%.8f", a); break;
      case 9: sprintf(text, "%.9f", a); break;
      case 10: sprintf(text, "%.10f", a); break;
      case 11: sprintf(text, "%.11f", a); break;
      case 12: sprintf(text, "%.12f", a); break;
      case 13: sprintf(text, "%.13f", a); break;
      case 14: sprintf(text, "%.14f", a); break;
      case 15: sprintf(text, "%.15f", a); break;
      default: sprintf(text, "%.16g", a); break; 
  }    
  int negationSymbol = 0;
  if(a >= 0 && orderSigns) negationSymbol = 8;
  return print(text, x + negationSymbol, y, color, bg, color2, forceLength);
}

//Draws a single character (actually the same as drawletter)
int cprint(unsigned char n, int x, int y, ColorRGB color, bool bg, ColorRGB color2)
{
   drawLetter(n, x, y, color, bg, color2);
   return 1;
}

//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//TEXT INPUT FUNCTIONS//////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//

bool keyReleased[256];

//Returns American keyboard key pressed, including characters behind "shift". Also requires you to release key before returning the same value again.
Uint8 getAlphaNumeric()
{
    readKeys();
    char key = 0;
    if(!(inkeys[SDLK_CAPSLOCK] || inkeys[SDLK_RSHIFT] || inkeys[SDLK_LSHIFT]))
    {
        if(inkeys[SDLK_a]) {if(keyReleased[0]) {key = 'a'; keyReleased[0] = 0;}} else keyReleased[0] = 1;
        if(inkeys[SDLK_b]) {if(keyReleased[1]) {key = 'b'; keyReleased[1] = 0;}} else keyReleased[1] = 1;
        if(inkeys[SDLK_c]) {if(keyReleased[2]) {key = 'c'; keyReleased[2] = 0;}} else keyReleased[2] = 1;
        if(inkeys[SDLK_d]) {if(keyReleased[3]) {key = 'd'; keyReleased[3] = 0;}} else keyReleased[3] = 1;
        if(inkeys[SDLK_e]) {if(keyReleased[4]) {key = 'e'; keyReleased[4] = 0;}} else keyReleased[4] = 1;
        if(inkeys[SDLK_f]) {if(keyReleased[5]) {key = 'f'; keyReleased[5] = 0;}} else keyReleased[5] = 1;
        if(inkeys[SDLK_g]) {if(keyReleased[6]) {key = 'g'; keyReleased[6] = 0;}} else keyReleased[6] = 1;
        if(inkeys[SDLK_h]) {if(keyReleased[7]) {key = 'h'; keyReleased[7] = 0;}} else keyReleased[7] = 1;
        if(inkeys[SDLK_i]) {if(keyReleased[8]) {key = 'i'; keyReleased[8] = 0;}} else keyReleased[8] = 1;
        if(inkeys[SDLK_j]) {if(keyReleased[9]) {key = 'j'; keyReleased[9] = 0;}} else keyReleased[9] = 1;
        if(inkeys[SDLK_k]) {if(keyReleased[10]) {key = 'k'; keyReleased[10] = 0;}} else keyReleased[10] = 1;
        if(inkeys[SDLK_l]) {if(keyReleased[11]) {key = 'l'; keyReleased[11] = 0;}} else keyReleased[11] = 1;
        if(inkeys[SDLK_m]) {if(keyReleased[12]) {key = 'm'; keyReleased[12] = 0;}} else keyReleased[12] = 1;
        if(inkeys[SDLK_n]) {if(keyReleased[13]) {key = 'n'; keyReleased[13] = 0;}} else keyReleased[13] = 1;
        if(inkeys[SDLK_o]) {if(keyReleased[14]) {key = 'o'; keyReleased[14] = 0;}} else keyReleased[14] = 1;
        if(inkeys[SDLK_p]) {if(keyReleased[15]) {key = 'p'; keyReleased[15] = 0;}} else keyReleased[15] = 1;
        if(inkeys[SDLK_q]) {if(keyReleased[16]) {key = 'q'; keyReleased[16] = 0;}} else keyReleased[16] = 1;
        if(inkeys[SDLK_r]) {if(keyReleased[17]) {key = 'r'; keyReleased[17] = 0;}} else keyReleased[17] = 1;
        if(inkeys[SDLK_s]) {if(keyReleased[18]) {key = 's'; keyReleased[18] = 0;}} else keyReleased[18] = 1;
        if(inkeys[SDLK_t]) {if(keyReleased[19]) {key = 't'; keyReleased[19] = 0;}} else keyReleased[19] = 1;
        if(inkeys[SDLK_u]) {if(keyReleased[20]) {key = 'u'; keyReleased[20] = 0;}} else keyReleased[20] = 1;
        if(inkeys[SDLK_v]) {if(keyReleased[21]) {key = 'v'; keyReleased[21] = 0;}} else keyReleased[21] = 1;
        if(inkeys[SDLK_w]) {if(keyReleased[22]) {key = 'w'; keyReleased[22] = 0;}} else keyReleased[22] = 1;
        if(inkeys[SDLK_x]) {if(keyReleased[23]) {key = 'x'; keyReleased[23] = 0;}} else keyReleased[23] = 1;
        if(inkeys[SDLK_y]) {if(keyReleased[24]) {key = 'y'; keyReleased[24] = 0;}} else keyReleased[24] = 1;
        if(inkeys[SDLK_z]) {if(keyReleased[25]) {key = 'z'; keyReleased[25] = 0;}} else keyReleased[25] = 1;
        if(inkeys[SDLK_0]) {if(keyReleased[36]) {key = '0'; keyReleased[36] = 0;}} else keyReleased[36] = 1;
        if(inkeys[SDLK_1]) {if(keyReleased[37]) {key = '1'; keyReleased[37] = 0;}} else keyReleased[37] = 1;
        if(inkeys[SDLK_2]) {if(keyReleased[38]) {key = '2'; keyReleased[38] = 0;}} else keyReleased[38] = 1;
        if(inkeys[SDLK_3]) {if(keyReleased[39]) {key = '3'; keyReleased[39] = 0;}} else keyReleased[39] = 1;
        if(inkeys[SDLK_4]) {if(keyReleased[40]) {key = '4'; keyReleased[40] = 0;}} else keyReleased[40] = 1;
        if(inkeys[SDLK_5]) {if(keyReleased[41]) {key = '5'; keyReleased[41] = 0;}} else keyReleased[41] = 1;
        if(inkeys[SDLK_6]) {if(keyReleased[42]) {key = '6'; keyReleased[42] = 0;}} else keyReleased[42] = 1;
        if(inkeys[SDLK_7]) {if(keyReleased[43]) {key = '7'; keyReleased[43] = 0;}} else keyReleased[43] = 1;
        if(inkeys[SDLK_8]) {if(keyReleased[44]) {key = '8'; keyReleased[44] = 0;}} else keyReleased[44] = 1;
        if(inkeys[SDLK_9]) {if(keyReleased[45]) {key = '9'; keyReleased[45] = 0;}} else keyReleased[45] = 1;     
        if(inkeys[SDLK_QUOTE])       {if(keyReleased[52]) {key = '\'';keyReleased[52] = 0;}} else keyReleased[52] = 1;
        if(inkeys[SDLK_COMMA])       {if(keyReleased[57]) {key = ','; keyReleased[57] = 0;}} else keyReleased[57] = 1;
        if(inkeys[SDLK_MINUS])       {if(keyReleased[58]) {key = '-'; keyReleased[58] = 0;}} else keyReleased[58] = 1;
        if(inkeys[SDLK_PERIOD])      {if(keyReleased[59]) {key = '.'; keyReleased[59] = 0;}} else keyReleased[59] = 1;
        if(inkeys[SDLK_SLASH])       {if(keyReleased[60]) {key = '/'; keyReleased[60] = 0;}} else keyReleased[60] = 1;
        if(inkeys[SDLK_SEMICOLON])   {if(keyReleased[62]) {key = ';'; keyReleased[62] = 0;}} else keyReleased[62] = 1;
        if(inkeys[SDLK_EQUALS])      {if(keyReleased[64]) {key = '='; keyReleased[64] = 0;}} else keyReleased[64] = 1;
        if(inkeys[SDLK_LEFTBRACKET]) {if(keyReleased[68]) {key = '['; keyReleased[68] = 0;}} else keyReleased[68] = 1;
        if(inkeys[SDLK_BACKSLASH])   {if(keyReleased[69]) {key = '\\';keyReleased[69] = 0;}} else keyReleased[69] = 1;
        if(inkeys[SDLK_RIGHTBRACKET]){if(keyReleased[70]) {key = ']'; keyReleased[70] = 0;}} else keyReleased[70] = 1;
        if(inkeys[SDLK_BACKQUOTE])   {if(keyReleased[73]) {key = '`'; keyReleased[73] = 0;}} else keyReleased[73] = 1;           
    }    
    else
    {
        if(inkeys[SDLK_a]) {if(keyReleased[0]) {key = 'A'; keyReleased[0] = 0;}} else keyReleased[0] = 1;
        if(inkeys[SDLK_b]) {if(keyReleased[1]) {key = 'B'; keyReleased[1] = 0;}} else keyReleased[1] = 1;
        if(inkeys[SDLK_c]) {if(keyReleased[2]) {key = 'C'; keyReleased[2] = 0;}} else keyReleased[2] = 1;
        if(inkeys[SDLK_d]) {if(keyReleased[3]) {key = 'D'; keyReleased[3] = 0;}} else keyReleased[3] = 1;
        if(inkeys[SDLK_e]) {if(keyReleased[4]) {key = 'E'; keyReleased[4] = 0;}} else keyReleased[4] = 1;
        if(inkeys[SDLK_f]) {if(keyReleased[5]) {key = 'F'; keyReleased[5] = 0;}} else keyReleased[5] = 1;
        if(inkeys[SDLK_g]) {if(keyReleased[6]) {key = 'G'; keyReleased[6] = 0;}} else keyReleased[6] = 1;
        if(inkeys[SDLK_h]) {if(keyReleased[7]) {key = 'H'; keyReleased[7] = 0;}} else keyReleased[7] = 1;
        if(inkeys[SDLK_i]) {if(keyReleased[8]) {key = 'I'; keyReleased[8] = 0;}} else keyReleased[8] = 1;
        if(inkeys[SDLK_j]) {if(keyReleased[9]) {key = 'J'; keyReleased[9] = 0;}} else keyReleased[9] = 1;
        if(inkeys[SDLK_k]) {if(keyReleased[10]) {key = 'K'; keyReleased[10] = 0;}} else keyReleased[10] = 1;
        if(inkeys[SDLK_l]) {if(keyReleased[11]) {key = 'L'; keyReleased[11] = 0;}} else keyReleased[11] = 1;
        if(inkeys[SDLK_m]) {if(keyReleased[12]) {key = 'M'; keyReleased[12] = 0;}} else keyReleased[12] = 1;
        if(inkeys[SDLK_n]) {if(keyReleased[13]) {key = 'N'; keyReleased[13] = 0;}} else keyReleased[13] = 1;
        if(inkeys[SDLK_o]) {if(keyReleased[14]) {key = 'O'; keyReleased[14] = 0;}} else keyReleased[14] = 1;
        if(inkeys[SDLK_p]) {if(keyReleased[15]) {key = 'P'; keyReleased[15] = 0;}} else keyReleased[15] = 1;
        if(inkeys[SDLK_q]) {if(keyReleased[16]) {key = 'Q'; keyReleased[16] = 0;}} else keyReleased[16] = 1;
        if(inkeys[SDLK_r]) {if(keyReleased[17]) {key = 'R'; keyReleased[17] = 0;}} else keyReleased[17] = 1;
        if(inkeys[SDLK_s]) {if(keyReleased[18]) {key = 'S'; keyReleased[18] = 0;}} else keyReleased[18] = 1;
        if(inkeys[SDLK_t]) {if(keyReleased[19]) {key = 'T'; keyReleased[19] = 0;}} else keyReleased[19] = 1;
        if(inkeys[SDLK_u]) {if(keyReleased[20]) {key = 'U'; keyReleased[20] = 0;}} else keyReleased[20] = 1;
        if(inkeys[SDLK_v]) {if(keyReleased[21]) {key = 'V'; keyReleased[21] = 0;}} else keyReleased[21] = 1;
        if(inkeys[SDLK_w]) {if(keyReleased[22]) {key = 'W'; keyReleased[22] = 0;}} else keyReleased[22] = 1;
        if(inkeys[SDLK_x]) {if(keyReleased[23]) {key = 'X'; keyReleased[23] = 0;}} else keyReleased[23] = 1;
        if(inkeys[SDLK_y]) {if(keyReleased[24]) {key = 'Y'; keyReleased[24] = 0;}} else keyReleased[24] = 1;
        if(inkeys[SDLK_z]) {if(keyReleased[25]) {key = 'Z'; keyReleased[25] = 0;}} else keyReleased[25] = 1;
        if(inkeys[SDLK_0]) {if(keyReleased[36]) {key = ')'; keyReleased[36] = 0;}} else keyReleased[36] = 1;
        if(inkeys[SDLK_1]) {if(keyReleased[37]) {key = '!'; keyReleased[37] = 0;}} else keyReleased[37] = 1;
        if(inkeys[SDLK_2]) {if(keyReleased[38]) {key = '@'; keyReleased[38] = 0;}} else keyReleased[38] = 1;
        if(inkeys[SDLK_3]) {if(keyReleased[39]) {key = '#'; keyReleased[39] = 0;}} else keyReleased[39] = 1;
        if(inkeys[SDLK_4]) {if(keyReleased[40]) {key = '$'; keyReleased[40] = 0;}} else keyReleased[40] = 1;
        if(inkeys[SDLK_5]) {if(keyReleased[41]) {key = '%'; keyReleased[41] = 0;}} else keyReleased[41] = 1;
        if(inkeys[SDLK_6]) {if(keyReleased[42]) {key = '^'; keyReleased[42] = 0;}} else keyReleased[42] = 1;
        if(inkeys[SDLK_7]) {if(keyReleased[43]) {key = '&'; keyReleased[43] = 0;}} else keyReleased[43] = 1;
        if(inkeys[SDLK_8]) {if(keyReleased[44]) {key = '*'; keyReleased[44] = 0;}} else keyReleased[44] = 1;
        if(inkeys[SDLK_9]) {if(keyReleased[45]) {key = '('; keyReleased[45] = 0;}} else keyReleased[45] = 1;   
        if(inkeys[SDLK_QUOTE])       {if(keyReleased[52]) {key = '"'; keyReleased[52] = 0;}} else keyReleased[52] = 1;
        if(inkeys[SDLK_COMMA])       {if(keyReleased[57]) {key = '<'; keyReleased[57] = 0;}} else keyReleased[57] = 1;
        if(inkeys[SDLK_MINUS])       {if(keyReleased[58]) {key = '_'; keyReleased[58] = 0;}} else keyReleased[58] = 1;
        if(inkeys[SDLK_PERIOD])      {if(keyReleased[59]) {key = '>'; keyReleased[59] = 0;}} else keyReleased[59] = 1;
        if(inkeys[SDLK_SLASH])       {if(keyReleased[60]) {key = '?'; keyReleased[60] = 0;}} else keyReleased[60] = 1;
        if(inkeys[SDLK_SEMICOLON])   {if(keyReleased[62]) {key = ':'; keyReleased[62] = 0;}} else keyReleased[62] = 1;
        if(inkeys[SDLK_EQUALS])      {if(keyReleased[64]) {key = '+'; keyReleased[64] = 0;}} else keyReleased[64] = 1;
        if(inkeys[SDLK_LEFTBRACKET]) {if(keyReleased[68]) {key = '{'; keyReleased[68] = 0;}} else keyReleased[68] = 1;
        if(inkeys[SDLK_BACKSLASH])   {if(keyReleased[69]) {key = '|'; keyReleased[69] = 0;}} else keyReleased[69] = 1;
        if(inkeys[SDLK_RIGHTBRACKET]){if(keyReleased[70]) {key = '}'; keyReleased[70] = 0;}} else keyReleased[70] = 1;
        if(inkeys[SDLK_BACKQUOTE])   {if(keyReleased[73]) {key = '~'; keyReleased[73] = 0;}} else keyReleased[73] = 1;                     
    }    
    if(inkeys[SDLK_KP0]) {if(keyReleased[26]) {key = '0'; keyReleased[26] = 0;}} else keyReleased[26] = 1;
    if(inkeys[SDLK_KP1]) {if(keyReleased[27]) {key = '1'; keyReleased[27] = 0;}} else keyReleased[27] = 1;
    if(inkeys[SDLK_KP2]) {if(keyReleased[28]) {key = '2'; keyReleased[28] = 0;}} else keyReleased[28] = 1;
    if(inkeys[SDLK_KP3]) {if(keyReleased[29]) {key = '3'; keyReleased[29] = 0;}} else keyReleased[29] = 1;
    if(inkeys[SDLK_KP4]) {if(keyReleased[30]) {key = '4'; keyReleased[30] = 0;}} else keyReleased[30] = 1;
    if(inkeys[SDLK_KP5]) {if(keyReleased[31]) {key = '5'; keyReleased[31] = 0;}} else keyReleased[31] = 1;
    if(inkeys[SDLK_KP6]) {if(keyReleased[32]) {key = '6'; keyReleased[32] = 0;}} else keyReleased[32] = 1;
    if(inkeys[SDLK_KP7]) {if(keyReleased[33]) {key = '7'; keyReleased[33] = 0;}} else keyReleased[33] = 1;
    if(inkeys[SDLK_KP8]) {if(keyReleased[34]) {key = '8'; keyReleased[34] = 0;}} else keyReleased[34] = 1;
    if(inkeys[SDLK_KP9]) {if(keyReleased[35]) {key = '9'; keyReleased[35] = 0;}} else keyReleased[35] = 1;      
    if(inkeys[SDLK_KP_PERIOD])  {if(keyReleased[74]) {key = '.'; keyReleased[74] = 0;}} else keyReleased[74] = 1;
    if(inkeys[SDLK_KP_DIVIDE])  {if(keyReleased[75]) {key = '/'; keyReleased[75] = 0;}} else keyReleased[75] = 1;
    if(inkeys[SDLK_KP_PLUS])    {if(keyReleased[76]) {key = '+'; keyReleased[76] = 0;}} else keyReleased[76] = 1;
    if(inkeys[SDLK_KP_MINUS])   {if(keyReleased[77]) {key = '-'; keyReleased[77] = 0;}} else keyReleased[77] = 1;
    if(inkeys[SDLK_KP_MULTIPLY]){if(keyReleased[78]) {key = '*'; keyReleased[78] = 0;}} else keyReleased[78] = 1;
    if(inkeys[SDLK_KP_EQUALS])  {if(keyReleased[79]) {key = '='; keyReleased[79] = 0;}} else keyReleased[79] = 1;   
    if(inkeys[SDLK_SPACE])      {if(keyReleased[46]) {key = ' '; keyReleased[46] = 0;}} else keyReleased[46] = 1; 
        
    return key;      
} 

//Returns pressed number key
int getNumeric()
{
    readKeys();
    bool keyPressed = 0;
    int digit = -1;
    int returnValue = -1;
 
    if(inkeys[SDLK_KP0]) {if(keyReleased[26]) {digit = 0; keyReleased[26] = 0;}} else keyReleased[26] = 1;
    if(inkeys[SDLK_KP1]) {if(keyReleased[27]) {digit = 1; keyReleased[27] = 0;}} else keyReleased[27] = 1;
    if(inkeys[SDLK_KP2]) {if(keyReleased[28]) {digit = 2; keyReleased[28] = 0;}} else keyReleased[28] = 1;
    if(inkeys[SDLK_KP3]) {if(keyReleased[29]) {digit = 3; keyReleased[29] = 0;}} else keyReleased[29] = 1;
    if(inkeys[SDLK_KP4]) {if(keyReleased[30]) {digit = 4; keyReleased[30] = 0;}} else keyReleased[30] = 1;
    if(inkeys[SDLK_KP5]) {if(keyReleased[31]) {digit = 5; keyReleased[31] = 0;}} else keyReleased[31] = 1;
    if(inkeys[SDLK_KP6]) {if(keyReleased[32]) {digit = 6; keyReleased[32] = 0;}} else keyReleased[32] = 1;
    if(inkeys[SDLK_KP7]) {if(keyReleased[33]) {digit = 7; keyReleased[33] = 0;}} else keyReleased[33] = 1;
    if(inkeys[SDLK_KP8]) {if(keyReleased[34]) {digit = 8; keyReleased[34] = 0;}} else keyReleased[34] = 1;
    if(inkeys[SDLK_KP9]) {if(keyReleased[35]) {digit = 9; keyReleased[35] = 0;}} else keyReleased[35] = 1;
    if(inkeys[SDLK_0]) {if(keyReleased[36]) {digit = 0; keyReleased[36] = 0;}} else keyReleased[36] = 1;
    if(inkeys[SDLK_1]) {if(keyReleased[37]) {digit = 1; keyReleased[37] = 0;}} else keyReleased[37] = 1;
    if(inkeys[SDLK_2]) {if(keyReleased[38]) {digit = 2; keyReleased[38] = 0;}} else keyReleased[38] = 1;
    if(inkeys[SDLK_3]) {if(keyReleased[39]) {digit = 3; keyReleased[39] = 0;}} else keyReleased[39] = 1;
    if(inkeys[SDLK_4]) {if(keyReleased[40]) {digit = 4; keyReleased[40] = 0;}} else keyReleased[40] = 1;
    if(inkeys[SDLK_5]) {if(keyReleased[41]) {digit = 5; keyReleased[41] = 0;}} else keyReleased[41] = 1;
    if(inkeys[SDLK_6]) {if(keyReleased[42]) {digit = 6; keyReleased[42] = 0;}} else keyReleased[42] = 1;
    if(inkeys[SDLK_7]) {if(keyReleased[43]) {digit = 7; keyReleased[43] = 0;}} else keyReleased[43] = 1;
    if(inkeys[SDLK_8]) {if(keyReleased[44]) {digit = 8; keyReleased[44] = 0;}} else keyReleased[44] = 1;
    if(inkeys[SDLK_9]) {if(keyReleased[45]) {digit = 9; keyReleased[45] = 0;}} else keyReleased[45] = 1;
    //period: for floating point numbers: denoted by returning something higher than 9
    if(inkeys[SDLK_PERIOD]) {if(keyReleased[59]) {digit = 10; keyReleased[59] = 0;}} else keyReleased[59] = 1;
    if(inkeys[SDLK_KP_PERIOD]) {if(keyReleased[74]) {digit = 10; keyReleased[74] = 0;}} else keyReleased[74] = 1;
    //minus sign
    if(inkeys[SDLK_MINUS]) {if(keyReleased[58]) {digit = 11; keyReleased[58] = 0;}} else keyReleased[58] = 1;
    if(inkeys[SDLK_KP_MINUS]) {if(keyReleased[77]) {digit = 11; keyReleased[77] = 0;}} else keyReleased[77] = 1;
    

    return digit; //no relevant key pressed
}

//Allows you to enter a single character and press enter to accept
Uint8 getChar(char * message, int x, int y, ColorRGB color, bool bg, ColorRGB color2)
{

    int pos = print(message, x, y, color, bg, color2);
    int x2 = pos / h, y2 = pos % h;  
    bool enter = 0;
    Uint8 character = 0;
    while(enter == 0)
    {
        if(done()) end();
        Uint8 temp = getAlphaNumeric();
        if(temp > 0) character = temp;  
        cprint(character, x2, y2, color, 1, color2);
        redraw();
        if((inkeys[SDLK_RETURN] || inkeys[SDLK_KP_ENTER]) && keyReleased[100]) {keyReleased[100] = 0; enter = 1;}
        if(!(inkeys[SDLK_RETURN] || inkeys[SDLK_KP_ENTER])) keyReleased[100] = 1;
    }  
    return character;   
}

//returns a string, length is the maximum length of the given string array
void getString(char * text, int length, char * message, int x, int y, ColorRGB color, bool bg, ColorRGB color2)
{
    int pos = print(message, x, y, color, bg, color2);
    int x2 = pos / h, y2 = pos % h;  
    redraw();
    bool enter = 0;
    bool change = 1;
    int position = 0, maxPos = 0;
    for(int i = 0; i < length; i++) text[i] = 0;
    while(enter == 0)
    {
        if(done()) end();
        Uint8 temp = getAlphaNumeric();
        if(temp > 0) 
        {
            text[position] = temp;
            if(position < length - 1) position++; else maxPos = length;
            if(position > maxPos) maxPos = position;
            change = 1;
        }    
        if(inkeys[SDLK_BACKSPACE] && keyReleased[101] && position > 0) {if(position < length - 1 || text[position] == 0) position--; text[position] = 0; change = 1; keyReleased[101] = 0;}
        if(!inkeys[SDLK_BACKSPACE]) keyReleased[101] = 1;
        if(change)
        {            
            print(text, x2, y2, color, 1, color2, maxPos);
            redraw();            
        }           
        if((inkeys[SDLK_RETURN] || inkeys[SDLK_KP_ENTER]) && keyReleased[100]) {keyReleased[100] = 0; enter = 1;}
        if(!(inkeys[SDLK_RETURN] || inkeys[SDLK_KP_ENTER])) keyReleased[100] = 1;       
    }       
}

//returns a scalar that you have to type in
Scalar getScalar(char * message, int x, int y, ColorRGB color, bool bg, ColorRGB color2)
{
    int pos = print(message, x, y, color, bg, color2);
    int x2 = pos / h, y2 = pos % h;  
    
    redraw();
    bool enter = 0;
    bool change = 1;
    int position = 0, maxPos = 0;
    
    char number[256];
    for(int i = 0; i < 256; i++) number[i] = 0;
    Scalar value = 0;
    Scalar dc = 1;
    int sign = 1;
    
    while(enter == 0)
    {
        if(done()) end();
        int temp = getNumeric();
        if(temp > -1 && temp < 10) 
        {
            number[position] = temp + 48;
            if(position < 256 - 1) 
            {
                position++; 
                if(dc == 1)
                {
                    value *= 10;
                    value += sign * temp;
                }    
                else if(dc > 0 && dc < 1)
                {
                    value += sign * dc * temp;
                    dc /= 10;
                }    
            }    
            else maxPos = 256;
            if(position > maxPos) maxPos = position;
            change = 1;
        }
        else if(temp == 10 && dc == 1) 
        {
            number[position] = 46;
            if(position < 256 - 1) 
            {
                position++; 
                dc = 0.1;  
            }    
            else maxPos = 256;
            if(position > maxPos) maxPos = position;
            change = 1;
        }    
        else if(temp == 11 && position == 0)
        {
            number[0] = '-';
            position = 1;
            sign = -1;
        }             
        if(inkeys[SDLK_BACKSPACE] && keyReleased[101] && position > 0)
        {
            if(position < 256 - 1 || number[position] == 0) position--; 
            int currentDigit = number[position];
            if(currentDigit == 46) 
            {
                currentDigit = 10;
                dc = 1;                 
            }
            else if(currentDigit == '-') 
            {
                currentDigit = 11;
                sign = 1;                
            }                
            else 
            {
                currentDigit -= 48;  
                if(dc == 1)
                {
                    value -= sign * currentDigit;
                    value /= 10;
                    if(value < 2) value = int(value);
                }
                else if(dc > 0 && dc < 1)
                {
                    dc *= 10;
                    value -= sign * dc * currentDigit;
                }                           
            }             
            number[position] = 0; 
            change = 1; 
            keyReleased[101] = 0;
        }
        if(!inkeys[SDLK_BACKSPACE]) keyReleased[101] = 1;
        if(change)
        {            
            print(number, x2, y2, color, 1, color2, maxPos);
            //fprint(value, 16, x2, y2 + 8, color, 1, color2, 0, maxPos); //to test if scalar is actually correct
            redraw();       
        }           
        if((inkeys[SDLK_RETURN] || inkeys[SDLK_KP_ENTER]) && keyReleased[100]) {keyReleased[100] = 0; enter = 1;}
        if(!(inkeys[SDLK_RETURN] || inkeys[SDLK_KP_ENTER])) keyReleased[100] = 1;       
    }    
    return value;   
}

//****************************************************************************//
////////////////////////////////////////////////////////////////////////////////
//DATA//////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//****************************************************************************//


//The full original IBM ASCII character set, 8*8 pixels per character
const bool font[256][8][8]=
{
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//0

0,1,1,1,1,1,1,0,
1,0,0,0,0,0,0,1,
1,0,1,0,0,1,0,1,
1,0,0,0,0,0,0,1,
1,0,1,1,1,1,0,1,
1,0,0,1,1,0,0,1,
1,0,0,0,0,0,0,1,
0,1,1,1,1,1,1,0,
//1

0,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,1,
1,1,0,1,1,0,1,1,
1,1,1,1,1,1,1,1,
1,1,0,0,0,0,1,1,
1,1,1,0,0,1,1,1,
1,1,1,1,1,1,1,1,
0,1,1,1,1,1,1,0,
//2

0,1,1,0,1,1,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,0,
0,1,1,1,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//3

0,0,0,1,0,0,0,0,
0,0,1,1,1,0,0,0,
0,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,0,
0,1,1,1,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//4

0,0,1,1,1,0,0,0,
0,1,1,1,1,1,0,0,
0,0,1,1,1,0,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,0,
1,1,0,1,0,1,1,0,
0,0,0,1,0,0,0,0,
0,0,1,1,1,0,0,0,
//5

0,0,0,1,0,0,0,0,
0,0,0,1,0,0,0,0,
0,0,1,1,1,0,0,0,
0,1,1,1,1,1,0,0,
1,1,1,1,1,1,1,0,
0,1,1,1,1,1,0,0,
0,0,0,1,0,0,0,0,
0,0,1,1,1,0,0,0,
//6

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//7

1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,0,0,1,1,1,
1,1,0,0,0,0,1,1,
1,1,0,0,0,0,1,1,
1,1,1,0,0,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
//8

0,0,0,0,0,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//9

1,1,1,1,1,1,1,1,
1,1,0,0,0,0,1,1,
1,0,0,1,1,0,0,1,
1,0,1,1,1,1,0,1,
1,0,1,1,1,1,0,1,
1,0,0,1,1,0,0,1,
1,1,0,0,0,0,1,1,
1,1,1,1,1,1,1,1,
//10

0,0,0,0,1,1,1,1,
0,0,0,0,0,1,1,1,
0,0,0,0,1,1,1,1,
0,1,1,1,1,1,0,1,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
//11

0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
//12

0,0,1,1,1,1,1,1,
0,0,1,1,0,0,1,1,
0,0,1,1,1,1,1,1,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,0,0,0,0,0,
//13

0,1,1,1,1,1,1,1,
0,1,1,0,0,0,1,1,
0,1,1,1,1,1,1,1,
0,1,1,0,0,0,1,1,
0,1,1,0,0,0,1,1,
0,1,1,0,0,1,1,1,
1,1,1,0,0,1,1,0,
1,1,0,0,0,0,0,0,
//14

1,0,0,1,1,0,0,1,
0,1,0,1,1,0,1,0,
0,0,1,1,1,1,0,0,
1,1,1,0,0,1,1,1,
1,1,1,0,0,1,1,1,
0,0,1,1,1,1,0,0,
0,1,0,1,1,0,1,0,
1,0,0,1,1,0,0,1,
//15

1,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,0,0,0,
1,1,1,0,0,0,0,0,
1,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//16

0,0,0,0,0,0,1,0,
0,0,0,0,1,1,1,0,
0,0,1,1,1,1,1,0,
1,1,1,1,1,1,1,0,
0,0,1,1,1,1,1,0,
0,0,0,0,1,1,1,0,
0,0,0,0,0,0,1,0,
0,0,0,0,0,0,0,0,
//17

0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
//18

0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
0,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//19

0,1,1,1,1,1,1,1,
1,1,0,1,1,0,1,1,
1,1,0,1,1,0,1,1,
0,1,1,1,1,0,1,1,
0,0,0,1,1,0,1,1,
0,0,0,1,1,0,1,1,
0,0,0,1,1,0,1,1,
0,0,0,0,0,0,0,0,
//20

0,1,1,1,1,1,1,0,
1,1,0,0,0,0,1,1,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
1,0,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
//21

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
0,1,1,1,1,1,1,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//22

0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,1,1,1,
//23

0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//24

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//25

0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,1,1,0,0,
1,1,1,1,1,1,1,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//26

0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,1,1,1,0,
0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//27

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//28

0,0,0,0,0,0,0,0,
0,0,1,0,0,1,0,0,
0,1,1,0,0,1,1,0,
1,1,1,1,1,1,1,1,
0,1,1,0,0,1,1,0,
0,0,1,0,0,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//29

0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//30

0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//31

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//32

0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//33 !

0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//34 "

0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
1,1,1,1,1,1,1,0,
0,1,1,0,1,1,0,0,
1,1,1,1,1,1,1,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//35 #

0,0,1,1,0,0,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//36 $

0,0,0,0,0,0,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//37 %

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,1,1,1,0,1,1,0,
1,1,0,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,0,1,1,0,
0,0,0,0,0,0,0,0,
//38 &

0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//39 '

0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//40 (

0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//41 )

0,0,0,0,0,0,0,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0,
1,1,1,1,1,1,1,1,
0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//42 *

0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//43 +

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
//44 ,

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//45 -

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//46 .

0,0,0,0,0,1,1,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//47 /

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,1,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,1,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//48 0

0,0,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//49 1

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//50 2

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//51 3

0,0,0,1,1,1,0,0,
0,0,1,1,1,1,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,1,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//52 4

1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//53 5

0,0,1,1,1,0,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//54 6

1,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//55 7

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//56 8

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//57 9

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//58 :

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
//59 ;

0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//60 <

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//61 =

0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//62 >

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//63 ?

0,1,1,1,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,0,1,1,1,1,0,
1,1,0,1,1,1,1,0,
1,1,0,1,1,1,1,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//64 @

0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//65 A

1,1,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//66 B

0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//67 C

1,1,1,1,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,1,1,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//68 D

1,1,1,1,1,1,1,0,
0,1,1,0,0,0,1,0,
0,1,1,0,1,0,0,0,
0,1,1,1,1,0,0,0,
0,1,1,0,1,0,0,0,
0,1,1,0,0,0,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//69 E

1,1,1,1,1,1,1,0,
0,1,1,0,0,0,1,0,
0,1,1,0,1,0,0,0,
0,1,1,1,1,0,0,0,
0,1,1,0,1,0,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//70 F

0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,1,1,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//71 G

1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//72 H

0,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//73 I

0,0,0,1,1,1,1,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//74 J

1,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,0,1,1,0,
1,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//75 K

1,1,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,1,0,
0,1,1,0,0,1,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//76 L

1,1,0,0,0,1,1,0,
1,1,1,0,1,1,1,0,
1,1,1,1,1,1,1,0,
1,1,0,1,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//77 M

1,1,0,0,0,1,1,0,
1,1,1,0,0,1,1,0,
1,1,1,1,0,1,1,0,
1,1,0,1,1,1,1,0,
1,1,0,0,1,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//78 N

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//79 O

1,1,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,1,1,1,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//80 P

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,1,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//81 Q

1,1,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,1,1,1,0,0,
0,1,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//82 R

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,0,0,0,0,0,
0,0,1,1,1,0,0,0,
0,0,0,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//83 S

1,1,1,1,1,1,0,0,
1,0,1,1,0,1,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//84 T

1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//85 U

1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//86 V

1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,1,0,1,1,0,
1,1,1,1,1,1,1,0,
1,1,1,0,1,1,1,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//87 W

1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//88 X

1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//89 Y

1,1,1,1,1,1,1,0,
1,1,0,0,1,1,0,0,
1,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,1,0,
1,1,0,0,0,1,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//90 Z

0,1,1,1,1,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//91 [

1,1,0,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,0,1,1,0,
0,0,0,0,0,0,1,0,
0,0,0,0,0,0,0,0,
//92 \

0,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//93 ]

0,0,0,1,0,0,0,0,
0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//94 ^

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
//95 _

0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//96 `

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,0,1,1,0,
0,0,0,0,0,0,0,0,
//97 a

1,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
1,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//98 b

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//99 c

0,0,0,1,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,0,1,1,0,
0,0,0,0,0,0,0,0,
//100 d

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//101 e

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//102 f

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,1,1,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
0,0,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
//103 g

1,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,1,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
1,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//104 h

0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//105 i

0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,0,1,1,0,0,0,
0,1,1,1,0,0,0,0,
//106 j

1,1,1,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,1,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//107 k

0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//108 l

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,0,1,1,0,0,
1,1,1,1,1,1,1,0,
1,1,0,1,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//109 m

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//110 n

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//111 o

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,1,1,1,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,0,0,0,0,
//112 p

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,1,1,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,1,1,1,1,0,
//113 q

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//114 r

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//115 s

0,0,0,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//116 t

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,0,1,1,0,
0,0,0,0,0,0,0,0,
//117 u

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//118 v

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,1,0,1,1,0,
1,1,1,1,1,1,1,0,
0,1,1,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//119 w

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
0,0,0,0,0,0,0,0,
//120 x

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
0,0,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
//121 y

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
1,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,1,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//122 z

0,0,0,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//123 {

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//124 |

1,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//125 }

0,1,1,1,0,1,1,0,
1,1,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//126 ~

0,0,0,1,0,0,0,0,
0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//127

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
//128

0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//129

0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//130

0,1,1,1,1,1,1,0,
1,1,0,0,0,0,1,1,
0,0,1,1,1,1,0,0,
0,0,0,0,0,1,1,0,
0,0,1,1,1,1,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
//131

1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//132

1,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//133

0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//134

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,1,0,0,
0,0,0,0,0,1,1,0,
0,0,1,1,1,1,0,0,
//135

0,1,1,1,1,1,1,0,
1,1,0,0,0,0,1,1,
0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,1,1,1,1,0,
0,1,1,0,0,0,0,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//136

1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//137

1,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//138

1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//139

0,1,1,1,1,1,0,0,
1,1,0,0,0,1,1,0,
0,0,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//140

1,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//141

1,1,0,0,1,1,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//142

0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//143

0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,1,1,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,1,1,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//144

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,1,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,1,1,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
//145

0,0,1,1,1,1,1,0,
0,1,1,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,1,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,1,0,
0,0,0,0,0,0,0,0,
//146

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//147

0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//148

0,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//149

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//150

0,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//151

0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
//152

1,1,0,0,0,1,1,0,
0,0,1,1,1,0,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,1,1,1,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//153

1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//154

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,1,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//155

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,0,1,0,0,
1,1,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,1,0,0,1,1,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//156

1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
1,1,1,1,1,1,0,0,
0,0,1,1,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//157

1,1,1,1,0,0,0,0,
1,1,0,1,1,0,0,0,
1,1,0,1,1,0,0,0,
1,1,1,1,0,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,1,1,1,1,0,
1,1,0,0,1,1,0,0,
0,0,0,0,1,1,1,0,
//158

0,0,0,0,1,1,1,0,
0,0,0,1,1,0,1,1,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,0,1,1,0,0,0,
0,1,1,1,0,0,0,0,
//159

0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//160

0,0,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//161

0,0,0,0,0,0,0,0,
0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//162

0,0,0,0,0,0,0,0,
0,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//163

0,0,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//164

1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,0,1,1,0,0,
1,1,1,1,1,1,0,0,
1,1,0,1,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//165

0,0,1,1,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//166

0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//167

0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//168

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//169

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//170

1,1,0,0,0,1,1,0,
1,1,0,0,1,1,0,0,
1,1,0,1,1,0,0,0,
0,0,1,1,1,1,1,0,
0,1,1,0,0,0,1,1,
1,1,0,0,1,1,1,0,
1,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
//171

1,1,0,0,0,1,1,0,
1,1,0,0,1,1,0,0,
1,1,0,1,1,0,0,0,
1,1,1,1,0,0,1,1,
0,1,1,0,0,1,1,1,
1,1,0,0,1,1,1,1,
1,0,0,1,1,1,1,1,
0,0,0,0,0,0,1,1,
//172

0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0,
//173

0,0,0,0,0,0,0,0,
0,0,1,1,0,0,1,1,
0,1,1,0,0,1,1,0,
1,1,0,0,1,1,0,0,
0,1,1,0,0,1,1,0,
0,0,1,1,0,0,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//174

0,0,0,0,0,0,0,0,
1,1,0,0,1,1,0,0,
0,1,1,0,0,1,1,0,
0,0,1,1,0,0,1,1,
0,1,1,0,0,1,1,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//175

0,0,1,0,0,0,1,0,
1,0,0,0,1,0,0,0,
0,0,1,0,0,0,1,0,
1,0,0,0,1,0,0,0,
0,0,1,0,0,0,1,0,
1,0,0,0,1,0,0,0,
0,0,1,0,0,0,1,0,
1,0,0,0,1,0,0,0,
//176

0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
//177

1,1,0,1,1,1,0,1,
0,1,1,1,0,1,1,1,
1,1,0,1,1,1,0,1,
0,1,1,1,0,1,1,1,
1,1,0,1,1,1,0,1,
0,1,1,1,0,1,1,1,
1,1,0,1,1,1,0,1,
0,1,1,1,0,1,1,1,
//178

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//179

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//180

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//181

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//182

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//183

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//184

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,0,1,1,0,
0,0,0,0,0,1,1,0,
1,1,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//185

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//186

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,1,1,0,
1,1,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//187

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,0,1,1,0,
0,0,0,0,0,1,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//188

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//189

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//190

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//191

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//192

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//193

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//194

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//195

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//196

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//197

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//198

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//199

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,1,
0,0,1,1,0,0,0,0,
0,0,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//200

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,1,1,1,1,
0,0,1,1,0,0,0,0,
0,0,1,1,0,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//201

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,0,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//202

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,0,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//203

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,1,
0,0,1,1,0,0,0,0,
0,0,1,1,0,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//204

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//205

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,0,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,0,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//206

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//207

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//208

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//209

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//210

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//211

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//212

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//213

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,1,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//214

0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
1,1,1,1,0,1,1,1,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
0,0,1,1,0,1,1,0,
//215

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//216

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//217

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,1,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//218

1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
//219

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
//220

1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
1,1,1,1,0,0,0,0,
//221

0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
0,0,0,0,1,1,1,1,
//222

1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//223

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,1,1,0,
1,1,0,1,1,1,0,0,
1,1,0,0,1,0,0,0,
1,1,0,1,1,1,0,0,
0,1,1,1,0,1,1,0,
0,0,0,0,0,0,0,0,
//224

0,0,0,0,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,1,1,1,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
//225

0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//226

0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//227

1,1,1,1,1,1,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,1,1,0,
1,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
//228

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//229

0,0,0,0,0,0,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,1,1,1,1,1,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
//230

0,0,0,0,0,0,0,0,
0,1,1,1,0,1,1,0,
1,1,0,1,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//231

1,1,1,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,1,1,0,0,0,0,
1,1,1,1,1,1,0,0,
//232

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,1,1,1,1,1,0,
1,1,0,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//233

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
1,1,0,0,0,1,1,0,
1,1,0,0,0,1,1,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
1,1,1,0,1,1,1,0,
0,0,0,0,0,0,0,0,
//234

0,0,0,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,1,1,1,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,1,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
//235

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
1,1,0,1,1,0,1,1,
1,1,0,1,1,0,1,1,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//236

0,0,0,0,0,1,1,0,
0,0,0,0,1,1,0,0,
0,1,1,1,1,1,1,0,
1,1,0,1,1,0,1,1,
1,1,0,1,1,0,1,1,
0,1,1,1,1,1,1,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
//237

0,0,1,1,1,1,0,0,
0,1,1,0,0,0,0,0,
1,1,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
1,1,0,0,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//238

0,1,1,1,1,0,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,0,0,
//239

0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//240

0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//241

0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//242

0,0,0,1,1,0,0,0,
0,0,1,1,0,0,0,0,
0,1,1,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
//243

0,0,0,0,1,1,1,0,
0,0,0,1,1,0,1,1,
0,0,0,1,1,0,1,1,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
//244

0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
1,1,0,1,1,0,0,0,
1,1,0,1,1,0,0,0,
0,1,1,1,0,0,0,0,
//245

0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,1,1,0,0,0,0,
0,0,0,0,0,0,0,0,
//246

0,0,0,0,0,0,0,0,
0,1,1,1,0,0,1,0,
1,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,1,1,1,0,0,1,0,
1,0,0,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//247

0,0,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//248

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//249

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//250

0,0,0,0,1,1,1,1,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
0,0,0,0,1,1,0,0,
1,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,1,0,0,
//251

0,1,1,1,1,0,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,1,1,0,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//252

0,1,1,1,1,0,0,0,
0,0,0,0,1,1,0,0,
0,0,1,1,1,0,0,0,
0,1,1,0,0,0,0,0,
0,1,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//253

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,1,1,1,1,0,0,
0,0,1,1,1,1,0,0,
0,0,1,1,1,1,0,0,
0,0,1,1,1,1,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//254

0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
//255

};






