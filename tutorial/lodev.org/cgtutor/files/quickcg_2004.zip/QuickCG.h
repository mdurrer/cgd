/*
QuickCG

Copyright (c) 2004, Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

*) Redistributions of source code must retain the above copyright notice, this 
list of conditions and the following disclaimer.
*) Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _quickcg_h_
#define _quickcg_h_

#include <SDL/SDL.h>

////////////////////////////////////////////////////////////////////////////////
//MIN, MAX and Scalar///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//use with care: if a or b is a function, it's executed twice!
#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif
#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#endif

//define Scalar either as float or as double, at your choice
#define Scalar double

////////////////////////////////////////////////////////////////////////////////
//COLOR STRUCTS/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

struct ColorRGB8bit;
//a color with 3 components: r, g and b
struct ColorRGB
{
    int r;
    int g;
    int b;
    
    ColorRGB(Uint8 r, Uint8 g, Uint8 b);
    ColorRGB(ColorRGB8bit color);
    ColorRGB();
};
  
ColorRGB operator+(ColorRGB color, ColorRGB color2);
ColorRGB operator-(ColorRGB color, ColorRGB color2);
ColorRGB operator*(ColorRGB color, int a);
ColorRGB operator*(int a, ColorRGB color);
ColorRGB operator/(ColorRGB color, int a);
bool operator==(ColorRGB color, ColorRGB color2);
bool operator!=(ColorRGB color, ColorRGB color2);

#define RGB_Black   ColorRGB(  0,   0,   0)
#define RGB_Red     ColorRGB(255,   0,   0)
#define RGB_Green   ColorRGB(  0, 255,   0)
#define RGB_Blue    ColorRGB(  0,   0, 255)
#define RGB_Cyan    ColorRGB(  0, 255, 255)
#define RGB_Magenta ColorRGB(255,   0, 255)
#define RGB_Yellow  ColorRGB(255, 255,   0)
#define RGB_White   ColorRGB(255, 255, 255)   
#define RGB_Gray    ColorRGB(128, 128, 128)
#define RGB_Grey    ColorRGB(192, 192, 192)
#define RGB_Maroon    ColorRGB(128,   0,   0)
#define RGB_Darkgreen ColorRGB(  0, 128,   0)
#define RGB_Navy      ColorRGB(  0,   0, 128)
#define RGB_Teal      ColorRGB(  0, 128, 128)
#define RGB_Purple    ColorRGB(128,   0, 128)
#define RGB_Olive     ColorRGB(128, 128,   0)

//a color with 3 components: r, g and b
struct ColorRGB8bit
{
    Uint8 r;
    Uint8 g;
    Uint8 b;
    
    ColorRGB8bit(Uint8 r, Uint8 g, Uint8 b);
    ColorRGB8bit(ColorRGB color);
    ColorRGB8bit();
};
  
//a color with 3 components: h, s and l
struct ColorHSL
{
    int h;
    int s;
    int l;
    
    ColorHSL(Uint8 h, Uint8 s, Uint8 l);
    ColorHSL();
}; 
   
//a color with 3 components: h, s and v
struct ColorHSV
{
    int h;
    int s;
    int v;
    
    ColorHSV(Uint8 h, Uint8 s, Uint8 v);
    ColorHSV();
};

////////////////////////////////////////////////////////////////////////////////
//GLOBAL VARIABLES//////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

extern SDL_Surface *scr; //the single SDL surface used
extern int w;
extern int h;
extern Uint8 *inkeys;

////////////////////////////////////////////////////////////////////////////////
//BASIC SCREEN FUNCTIONS////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void screen(int width = 640, int height = 400, bool fullscreen = 0, char *text = " ");
void lock();
void unlock();
void redraw();
void cls(ColorRGB color = RGB_Black);
void pset(int x, int y, ColorRGB color);
ColorRGB pget(int x, int y);
void drawBuffer(Uint32 *buffer);
bool onScreen(int x, int y);

////////////////////////////////////////////////////////////////////////////////
//NON GRAPHICAL FUNCTIONS///////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void sleep();
void waitFrame(float oldTime, float mspf);
bool done();
void end();
void readKeys();
void getMouseState(int & mouseX, int & mouseY);
void getMouseState(int & mouseX, int & mouseY, bool & LMB, bool & RMB);
float getTime();

////////////////////////////////////////////////////////////////////////////////
//2D SHAPES/////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

bool horLine(int y, int x1, int x2, ColorRGB color);
bool verLine(int x, int y1, int y2, ColorRGB color);
bool drawLine(int x1, int y1, int x2, int y2, ColorRGB color);
bool drawCircle(int xc, int yc, int radius, ColorRGB color);
bool drawDisk(int xc, int yc, int radius, ColorRGB color);
bool drawRect(int x1, int y1, int x2, int y2, ColorRGB color);
bool clipLine(int x1,int y1,int x2, int y2, int & x3, int & y3, int & x4, int & y4);

////////////////////////////////////////////////////////////////////////////////
//COLOR CONVERSIONS/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
ColorHSL RGBtoHSL(ColorRGB colorRGB);
ColorRGB HSLtoRGB(ColorHSL colorHSL);
ColorHSV RGBtoHSV(ColorRGB colorRGB);
ColorRGB HSVtoRGB(ColorHSV colorHSV);
Uint32 RGBtoINT(ColorRGB colorRGB);
ColorRGB INTtoRGB(Uint32 colorINT);


////////////////////////////////////////////////////////////////////////////////
//BMP FUNCTIONS/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

int loadBMP(char *filename, ColorRGB *image, int w, int h);
int loadBMP(char *filename, Uint32 *image, int w, int h);

////////////////////////////////////////////////////////////////////////////////
//TEXT FUNCTIONS////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
extern const bool font[256][8][8];
static void inline drawLetter(unsigned char n, int x, int y, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black);
int print(char *text, int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black, int forceLength=0);
int iprint(int a, int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black, bool orderSigns=0, int forceLength=0);
int iprint(Uint32 a, int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black, bool orderSigns=0, int forceLength=0);
int fprint(double a, int length = 0, int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black, bool orderSigns=0, int forceLength=0);
int cprint(unsigned char n, int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black);

////////////////////////////////////////////////////////////////////////////////
//TEXT INPUT FUNCTIONS//////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
Uint8 getChar(char * message = "", int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black);
void getString(char * text, int length, char * message = "", int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black);
Scalar getScalar(char * message = "", int x = 0, int y = 0, ColorRGB color = RGB_White, bool bg = 0, ColorRGB color2 = RGB_Black);

#endif


