#include <cmath>
#include <cstdlib> //for random numbers: rand();
#include <SDL/SDL.h>
#include "QuickCG.h"
#include "Q3DMath.h"
using namespace std;

////////////////////////////////////////////////////////////////////////////////
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
//                           PUT CODE BELOW HERE                              //
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
////////////////////////////////////////////////////////////////////////////////



int main(int argc, char *argv[])
{
    screen(256, 256, 0, "Small Test Script");
    for(int x = 0; x < w; x++)
    for(int y = 0; y < h; y++)
    {
        pset(x, y, ColorRGB(x, y, 128));
    }
    redraw();
    sleep();
}       
