/*
QuickCG

Copyright (c) 2004, Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

*) Redistributions of source code must retain the above copyright notice, this 
list of conditions and the following disclaimer.
*) Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This file took me a lot of time and research to write, so please, if you use it,
give me credits.
*/

#ifndef __3DMATH_H__
#define __3DMATH_H__

#include "QuickCG.h"

////////////////////////////////////////////////////////////////////////////////
//               [ x ]                                                        //
// Vector Class  [ y ]                                                        //
//               [ z ]                                                        //
////////////////////////////////////////////////////////////////////////////////
class Vector3
{
    public:
               
    Scalar x;
    Scalar y;
    Scalar z;
    
    Vector3(Scalar x, Scalar y, Scalar z);
    Vector3();
    
    Scalar length();
    void normalize();
    Scalar distance(Vector3 v);
    Scalar dot(Vector3 v);
    Vector3 cross(Vector3 v);
};

Scalar length(Vector3 v);
Vector3 normalize(Vector3 v);
Scalar distance(Vector3 v, Vector3 w);       
Scalar dot(Vector3 v, Vector3 w);
Vector3 cross(Vector3 v, Vector3 w);
Vector3 operator-(Vector3 v, Vector3 w);
Vector3 operator-(Vector3 v);
Vector3 operator+(Vector3 v, Vector3 w);
Vector3 operator*(Vector3 v, Scalar a);
Vector3 operator*(Scalar a, Vector3 v);
Vector3 operator/(Vector3 v, Scalar a);
Scalar vectorAngle(Vector3 v, Vector3 w);
Vector3 rotateAroundArbitrary(Vector3 v, Vector3 axis, Scalar angle);

////////////////////////////////////////////////////////////////////////////////
//               [ a b c ]                                                    //
// Matrix Class  [ d e f ]                                                    //
//               [ g h i ]                                                    //
////////////////////////////////////////////////////////////////////////////////
class Matrix3
{
    public:
        
    Scalar a; Scalar b; Scalar c;
    Scalar d; Scalar e; Scalar f;
    Scalar g; Scalar h; Scalar i;
    
    Matrix3(Scalar a, Scalar b, Scalar c, Scalar d, Scalar e, Scalar f, Scalar g, Scalar h, Scalar i);
    Matrix3();
    
    void transpose();
    Scalar determinant();
    void inverse();   
};

Matrix3 transpose(Matrix3 A);
Scalar determinant(Matrix3 A);
Matrix3 inverse(Matrix3 A);
Matrix3 operator+(Matrix3 A, Matrix3 B);
Matrix3 operator-(Matrix3 A, Matrix3 B);
Matrix3 operator*(Matrix3 A, Scalar a);
Matrix3 operator*(Scalar a, Matrix3 A);
Matrix3 operator/(Matrix3 A, Scalar a);
Vector3 operator*(Matrix3 A, Vector3 v);
Vector3 operator*(Vector3 v, Matrix3 A);
Matrix3 operator*(Matrix3 A, Matrix3 B);


////////////////////////////////////////////////////////////////////////////////
//               [ u.x v.x dir.x ]   [ pos.x ]                                //
// Camera Class  [ u.y v.y dir.y ] + [ pos.y ]                                //
//               [ u.z v.z dir.z ]   [ pos.z ]                                //
////////////////////////////////////////////////////////////////////////////////
class Camera
{

    public:
    Scalar nearClip; //near clipping plane
    Scalar farClip; //far clipping plane

    Camera();
    Camera(Scalar posx, Scalar posy, Scalar posz,
           Scalar ux,   Scalar uy,   Scalar uz,
           Scalar vx,   Scalar vy,   Scalar vz,
           Scalar dirx, Scalar diry, Scalar dirz,
           Scalar nearClip, Scalar farClip);
                     
    //Get and Set the 4 important vectors 
    Vector3 getU(); //the "right" vector of the camera, x coordinate of screen
    Vector3 getV(); //the "up" vector of the camera, y coordinate of screen
    Vector3 getDir(); //the direction of the camera, vector that points into the screen (z direction)
    Vector3 getPos(); //the position of the camera in world coordinates
    void setDir(Vector3 newDir);
    void setU(Vector3 newY);
    void setV(Vector3 newV);    
    void setPos(Vector3 newPos);
    
    //move and rotate with vectors
    void move(Vector3 offset);
    void rotate(Vector3 axis, Scalar angle);
    void setLookDir(Vector3 newDir);
    void lookAt(Vector3 lookAtMe);
    
    //get and set distance to a certain point
    Scalar getDist(Vector3 point);
    void setDist(Vector3 point, Scalar dist);
    
    //get and set zoom
    Scalar getZoomU();
    Scalar getZoomV();
    void setZoomU(Scalar a);
    void setZoomV(Scalar a); 
    void zoom(Scalar a);
    void zoomU(Scalar a);
    void zoomV(Scalar a);
        
    //get and set FOV
    Scalar getFOVU();
    Scalar getFOVV();
    void setFOVU(Scalar angle);
    void setFOVV(Scalar angle);    
    
    //get and set pitch, yaw and roll (these are NOT native parameters of the camera and should normally never be needed!)   
    Scalar getYaw();
    Scalar getPitch();
    Scalar getRoll();      
    void setYaw(Scalar angle);
    void setPitch(Scalar angle);    
    void setRoll(Scalar angle);
    void yawPlanet(Scalar angle);
    void yawSpace(Scalar angle);  
    void pitch(Scalar angle);
    void roll(Scalar angle);
     
    //make camera orthogonal (reset skewing)
    Vector3 resetSkewU();
    Vector3 resetSkewV();
    
    //set screen ratio of the camera (ratio of length of u and v, e.g. 4:3, 16:9, 640:480, ...)
    Scalar getRatioUV();
    Scalar getRatioVU();
    void setRatioUV(Scalar ratio);
    void setRatioVU(Scalar ratio);
    
    //scale U, V and Dir without changing what you see
    Scalar getScale();
    void setScale(Scalar dirLength);
    void scale(Scalar factor);
    
    //generate, get and use the camera matrix to transform points
    void generateMatrix();
    Matrix3 getMatrix();
    Matrix3 getInvMatrix();
    void setMatrix(Matrix3 matrix);   //sets the u, v and dir vector to given matrix (and generates the actual matrix too of course)
    Vector3 transform(Vector3 v);
    bool projectOnScreen(Vector3 point, int & x, int & y, Scalar & z);
    bool projectOnScreen(Vector3 point, int & x, int & y);
    bool camSpaceToScreen(Vector3 point, int & x, int & y);                            
    
    private:
    //the camera plane, described by the vectors u and v, is described by "z = 0" in camera space
    Vector3 pos; //the location of the camera
    Vector3 u; //horizontal vector, horizontal side of computer screen
    Vector3 v; //vertical "up" vector, vertical side of computer screen
    Vector3 dir; //direction of the camera, direction of the projection
    Matrix3 camMatrix; //the camera matrix, is nothing more than the column vectors u, v and dir in one matrix
    Matrix3 invCamMatrix; //the inverse of the camera matrix     
};


//Auxiliary functions
//swap between radians and degrees
Scalar radToDeg(Scalar rad);
Scalar degToRad(Scalar deg);

#endif
