package com.brackeen.scared.action;

public interface Action {
    
    public void tick();
    
    public void unload();
    
    public boolean isFinished();
    
}
