/**
A simple app/game framework with a gameloop, scene graph, fixed-width bitmap fonts, and 
resource manager. Sits on top of AWT.
*/
package com.brackeen.app;