// stdafx.cpp : source file that includes just the standard includes
//	demopaja.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

/*
#include "logger/logger.h"



void
TRACE_LOG( const char* szFormat, ...  )
{
	char	szMsg[256];
	va_list	rList;
	va_start( rList, szFormat );
	_vsnprintf( szMsg, 255, szFormat, rList );
	va_end( rList );
//	OutputDebugString( szMsg );
	LOG( string( szMsg ) );
}
*/