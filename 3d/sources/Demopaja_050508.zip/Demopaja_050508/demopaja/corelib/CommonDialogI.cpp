#include "PajaTypes.h"
#include "ClassIdC.h"
#include "CommonDialogI.h"

using namespace PajaSystem;
using namespace PluginClass;

CommonDialogI::CommonDialogI()
{
	// empty
}

CommonDialogI::~CommonDialogI()
{
	// empty
}
