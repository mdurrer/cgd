
#include "ClassDescC.h"


using namespace PluginClass;

ClassDescC::ClassDescC()
{
	// empty
}

ClassDescC::~ClassDescC()
{
	// empty
}
