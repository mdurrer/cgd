If you are using the DX8 device driver mail me!

--memon
<memon@inside.org>