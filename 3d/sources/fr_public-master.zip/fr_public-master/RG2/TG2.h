// This code is in the public domain. See LICENSE for details.

// TG2.h
