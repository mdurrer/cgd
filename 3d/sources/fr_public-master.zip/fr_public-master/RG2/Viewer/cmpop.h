// This code is in the public domain. See LICENSE for details.

#ifndef __cmpop_h_
#define __cmpop_h_

extern void cmpPaintFrame();

#endif
