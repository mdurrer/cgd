fr-024: welcome to...

...another long-time-prepared and short-time-finished
farbrausch product!

this is the official breakpoint 2003 pc invitation. breakpoint is a
new german party at easter meant to help all those sceners who don't
know how to spend that weekend after mekka&symposium sadly gave up...

refer to http://breakpoint.untergrund.net for details or just mails us
at breakpoint@untergrund.net


with that said, some details about the actual intro (as always): it
should work pretty much everywhere this time, albeit it will probably
be kinda slow on older computers (sorry, but high poly count and trans-
parencies is what makes this prod look good, so no compromises here).
in the hopefully unlikely case that you still have problems getting it
to run, contact me at fg@farb-rausch.de, again, as always. (though i
hope we won't need a final version FOR ONCE :)

fast credits:
  - giZMo (textures, camera, animation, scene design)
  - ryg (main code and additional gfx)
  - kb (sound code and music)
  
no one else involved this time!

greets must (as always) go to haujobb, kolor, threestate, threepixels,
aardbei, mfx, kewlers, calodox, vantage, headcrash, vacuum, moppi prods.,
deusexmachina, cryonics, the pimp brigade, damage, the black lotus, SCALA,
federation against nature, black maiden, bypass, noice, fairlight,
spinning kids, unique, tpolm, and, unik, t-rex, sunflower, foobug, exceed,
epidemic, orion, asd, da jormas, satori, cocoon, smash designs, popsy
team, and all i forgot (again, as always).

-ryg/farbrausch

---

http://breakpoint.untergrund.net
http://www.farb-rausch.com