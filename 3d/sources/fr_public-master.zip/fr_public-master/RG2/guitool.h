// This code is in the public domain. See LICENSE for details.

#ifndef __RG2_GUITOOL_H_
#define __RG2_GUITOOL_H_

#include "types.h"

extern sF32 gridMapStep(sF32 mx, sInt cnt, sF32 radix);

#endif
