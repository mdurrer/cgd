// This code is in the public domain. See LICENSE for details.

// stdafx.cpp : source file that includes just the standard includes
//	TG2.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
