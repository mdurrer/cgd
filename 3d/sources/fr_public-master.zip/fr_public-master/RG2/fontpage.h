// This code is in the public domain. See LICENSE for details.

#ifndef __FONTPAGE_H_
#define __FONTPAGE_H_

#include "types.h"

struct frFontPage
{
};

#endif
