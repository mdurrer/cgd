fr-013: flybye

an invitation demo for the party 2001 by farbrausch creature shop
[this one is not yet official, but we didn't want to wait even longer
to release it since we're extremely late already]

Requirements:
- A fast PC
- A fast Graphics card with lots of VRAM (TNT2, 32MB+ recommended)
- A sound card
- 128MB of RAM or more (192MB or up strongly recommended)

People involved:
 -ryg: Main Intro/Tool code, Sync and additional Graphics
 -giZMo: Graphics, Lighting, Sync, Characters & Animations, Idea
 -exoticorn: Additional Textures and Models
 -kb: Soundsystem, Music and Sound FX
 -yoda: Additional Animations
 -torus: Additional operator code
 -shamada: Rigger
  

Final version to be expected.
Really.


http://www.theparty.dk
http://www.farb-rausch.com | http://farb-rausch.de

The Party? theparty@theparty.dk
Questions? fanmail@farb-rausch.de
Bugs?      hotline@farb-rausch.de

ALL CONTENTS IN THIS ARCHIVE ARE (C) 2001 FARBRAUSCH CREATURE SHOP,
GERMANY. COPYING AND DISTRIBUTION ARE ALLOWED AS LONG THE ORIGINAL CONTENTS
OF THE ARCHIVE REMAIN UNCHANGED AND YOU DON'T CHARGE ANY FEE FOR COPYING
OR DISTRIBUTION OF THIS ARCHIVE. THE CONTENT IS PROVIDED AS-IS, WITHOUT
ANY WARRANTY CONCERNING FUNCTION OR HARMLESSNESS. FARBRAUSCH CREATURE SHOP
CAN NOT BE MADE LIABLE FOR DAMAGES INCURRING DUE TO USE OF THE CONTENT.

[this readme blatantly copy&pasted from fr08, yes]