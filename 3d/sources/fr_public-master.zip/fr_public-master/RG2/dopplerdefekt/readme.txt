 fr-029: dopplerdefekt
	  cp++wf++ryg++kb
	  farbrausch 2002
	 
 duron 650/gf2gts/64mb

"scotty, i want real 3d
 in an intro."
"that'll be a 256kb one,
 then."
"i give you 64kb."
"i'll do it in 48."

----

short notes by ryg, ~45 mins before the deadline:
- the intro was produced in a timespan of about two
  weeks before and at the party. as always, we ran
  "slightly" out of time, so this isn't nearly as
  polished or well-synched as we'd like it to be.
- it burns fillrate like hell and uses far too much
  cpu by now. expect a fixed final (as always, sigh).
- problems? hotline@farb-rausch.de
- greets: all who deserve it and those i forgot.

	farbrausch end of 2002.
	
- small update on 29.12.2002, before upload to scene.org:
  (the exe itself is untouched, just a new readme :)
  you need *red-cyan* 3d glasses and geforce1 or better to
  be able to enjoy this intro. red-blue glasses work ok too,
  but you don't really see the colors; red-green wasn't tested.
- as we're probably going to need a final version anyway :),
	expect some (hopefully minor) fixes and a no3d-switch for
	people who either don't have the glasses or the fillrate.