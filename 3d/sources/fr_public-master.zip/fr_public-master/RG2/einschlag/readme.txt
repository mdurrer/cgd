farbrausch laboratories proudly present

	fr-022: ein.schlag
	ms2002, pc intro 64k, #2
    finally a final version

    cp / kb / ryg / wayfinder (development)
	gizmo / exoticorn / bombe (rg2 evaluation+moral support)

---

after far too much time after ms2002, we're back again with a
new, fixed, faster, more compatible, freshly repainted and ofcourse
final version of our beloved intro ein.schlag

---

changes:
- updated & improved content
- vastly improved hidDEN part (yes, it really exists!)
- the long-mysterious matrox bug was finally found & fixed (thanks must
  go to chaos for that one)
- increased performance & shorter precalculation time
- slightly improved sound system
- final versions should be smaller than party versions (tm)
- lots of small changes

---

needs pentium II or better and nvidia tnt (or better) graphics card.
we recommend 600 MHz (or more) and a geforce-class graphics card (or
better) for maximum enjoyment.

tested successfully on every machine I threw it on.
works fine with ati (radeon or better), nvidia (tnt or better), and
matrox (g400+better, probably g200 too) cards.

needs directx 8.1.

---

the greets (no, the scrollers in the intro are long enough):
  kolor, mfx, freestyle, calodox, ex-haujobb, the pimp brigade,
  einklang.net, aardbei, satori, damage, bypass, blackmaiden,
  exceed, 3state, t-rex, kewlers, threepixels, unknwown productions,
  elerium core, smash designs, inf, ukonx, moppi productions, scenic,
  sunflower, copro, fan, tpolm, hornet, fuel and all we (delibarely?)
  forgot.

---

cp wants to thank:
  ryg and gizmo for doing the dirty job and making rg2 (our tool)
  as stable and powerful as it was when I first touched it,
  wayfinder for being as creative as I am not (sense? :)),
  critikill for ideas...

wayfinder says:
  ein.schlag means a lot to me, thanks everyone for their support!
  thanks ryg and kb for the tools, thanks chaos for inspiring us
  thanks #szene.ger, #trax, #k, #s, #buzz, #phatbuzz
  thanks gizmo for help getting started
  thanks paniq for criticizing the shit out of my music :D
  thanks farbrausch for being who you are

ryg wants to thank:
  jeff royle & the driver guys @ ati (awesome support!)
  ir, scali, scoop, ld0d & others @ ircnet #coders (beta testing)
  bombe, cp, exoticorn, gizmo, wayfinder (my favourite user base! :)
  and all my friends in the scene, ofcourse (not in the mood for typing
  4k personal greet lists :)

---

expect final versions of fr-013, 014 and 027 very soon now!