# py_free_kick
this is and old game I made long time ago, feel free to improve it!

## How to run it?

type in the commands terminal (traveling previously to the file directory)

    python main.py

or right click on main.py, open with->python

you need of couse python installed with the pygame library, for more instructions go to
https://www.python.org/ to install python
http://pygame.org/ to install pygame
