#pragma once

#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "SetupDialog.h"
#include "WindowHandler.h"
#include "Parser.h"
#include "mvx_lite.h"
#include "EventHandler.h"

