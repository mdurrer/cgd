#ifndef __filemenu__
#define __filemenu__

#include "ddgui.h"

void filemenu(int mode);

#endif