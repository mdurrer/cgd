#ifndef __intro__
#define __intro__

#include <windows.h>
#include <winuser.h>
#include <process.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "IntroWindow.h"
#include "alienprobe.h"
#include "copytest.h"
#include "IntroEngine.h"
#include "IntroInput.h"
#include "Vectors.h"
#include "Precalc.h"

#endif