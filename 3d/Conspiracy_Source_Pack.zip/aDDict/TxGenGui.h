#ifndef __TXGENGUI__
#define __TXGENGUI__

#include "addict.h"

extern unsigned int alayers[4];
int texturenum(tTexture *t);
void TextureGeneratorGUI(byte mode);

#endif