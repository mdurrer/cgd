// itt egyelore csak ez van

#define MUSICSIZE     8214
#define NUMCHANNELS   24
#define NUMPATTERNS   52
#define NUMISTRUMENTS 26
