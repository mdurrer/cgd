// itt egyelore csak ez van

#define MUSICSIZE     12759
#define NUMCHANNELS   18
#define NUMPATTERNS   77
#define NUMISTRUMENTS 41
