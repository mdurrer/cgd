#ifndef __cloth__
#define __cloth__

#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "vectors.h"

void initcloth();
void calculatecloth();
void drawcloth();


#endif