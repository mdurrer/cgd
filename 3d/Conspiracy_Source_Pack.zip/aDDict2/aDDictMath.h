#ifndef __aDDictMath__
#define __aDDictMath__

#define radtheta 3.141592654f/180.0f

/*float __cdecl sin(float v);
float __cdecl cos(float v);
float __cdecl sqrt(float v);
float __cdecl fabs(float v);*/

#endif