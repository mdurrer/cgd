#pragma once

void ParseASE(char *FileName);