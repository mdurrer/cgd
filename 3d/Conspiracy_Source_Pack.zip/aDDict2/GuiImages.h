#pragma once

#include "gui\buttons_01.h"
#include "gui\buttons_02.h"
#include "gui\buttons_03.h"
#include "gui\buttons_04.h"
#include "gui\buttons_05.h"
#include "gui\buttons_06.h"
#include "gui\buttons_07.h"
#include "gui\buttons_08.h"
