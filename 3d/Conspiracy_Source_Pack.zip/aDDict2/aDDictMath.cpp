#include "aDDictMath.h"

/*float __cdecl sin(float v)
{
	volatile float res;
	__asm
	{
		fld v
		fsin
		fstp res
	}
	return res;
}

float __cdecl cos(float v)
{
	volatile float res;
	__asm
	{
		fld v
		fcos
		fstp res
	}
	return res;
}

float __cdecl sqrt(float v)
{
	volatile float res;
	__asm
	{
		fld v
		fsqrt
		fstp res
	}
	return res;
}

float __cdecl fabs(float v)
{
	volatile float res;
	__asm
	{
		fld v
		fabs
		fstp res
	}
	return res;
}*/

