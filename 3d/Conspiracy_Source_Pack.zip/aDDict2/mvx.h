/*********************************************************************

                          #   # #   # #   #
                          ## ## #   #  # # 
                          # # # #   #   # 
                          #   #  # #   # # 
                          #   #   #   #   #

                  REALTIME BUZZ-BASED SYNTHESIZER

        Written by Gargaj/Conspiracy ^ �mla�t Design ^ CoolPHat

  "You've successfully proven that you can write a working softsynth, 
   now prove that you can write a good one :)"
                                                  /kb^farbrausch/

**********************************************************************/

#pragma once

/*#include <stdio.h>
#include <math.h>
#include <windows.h>
#define DWORD_PTR unsigned long *
#include <dsound.h>
#pragma comment(lib,"dsound.lib")

// SYSTEM
int mvxSystem_Init(HWND,char*);
void mvxSystem_Play(int);
int mvxSystem_GetSync();
void mvxSystem_Stop();
void mvxSystem_DeInit();*/

#undef cINTERFACE

