/**
 * Copyright (C) 2010 Ramesh Nair (www.hiddentao.com)
 * 
 * This is free software: you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) any later version.
 * 
 * This is distributed in the hope that it will  be useful, but WITHOUT ANY 
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.hiddentao.utils.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.RandomAccess;


/**
 * A static array whose capacity can be expanded.
 * 
 * Internally this wraps around a static Java array and ensures that it gets 
 * expanded whenever extra capacity is needed. 
 * 
 * This class acts as an efficient alternative to {@link ArrayList}. It tries 
 * to expose as array-like an API as possible, whilst still maintaining the 
 * ability to dynamically resize itself.
 * 
 * Neither this class nor its {@link Iterator} are thread-safe.
 * 
 * @author Ramesh Nair
 */
public final class DynamicArray<T> implements RandomAccess, Iterable<T>
{
	/**
	 * The default capacity of the array (16).
	 */
	private static final int DEFAULT_INITIAL_CAPACITY = 16;
	
	/**
	 * The default amount by which to increment the array's capacity when 
	 * expanding it (4).
	 */
	private static final int DEFAULT_INCREMENT = 4;
	
	/**
	 * The actual array.
	 */
	private Object[] iArray = null;
	
	/**
	 * The current maximum number of items allowed in the array, i.e. its size
	 * to the outside world.
	 */
	private int iSize = 0;
	
	/**
	 * The default amount by which to increment the array's capacity when 
	 * expanding it.
	 */
	private int iIncrement = 0;
	
	
	/**
	 * Constructor.
	 */
	public DynamicArray()
	{
		this(DEFAULT_INITIAL_CAPACITY, DEFAULT_INCREMENT);
	}
	
	/**
	 * Constructor.
	 * 
	 * @param aInitialCapacity the initial capacity of the array.
	 */
	public DynamicArray(int aInitialCapacity)
	{
		this(aInitialCapacity, DEFAULT_INCREMENT);
	}
	
	/**
	 * Constructor.
	 * 
	 * @param aInitialCapacity the initial capacity of the array.
	 * @param aIncrement the amount by which to increment the array capacity 
	 * when needed.
	 */
	public DynamicArray(int aInitialCapacity, int aIncrement)
	{
		iArray = new Object[aInitialCapacity];
		iIncrement = aIncrement;
	}
	
	
	/**
	 * Get the total number of items in the array.
	 * @return a non-negative integer.
	 */
	public int size()
	{
		return iSize;
	}
	
	
	
	/**
	 * Get an item at the given index of the array.
	 * 
	 * @param aIndex the index of the item to get.
	 * @return the item if one exists at the given index, otherwise null.
	 */
	public T get(int aIndex)
	{
		if (aIndex < iSize)
			return (T)iArray[aIndex];
		else
			return null;
	}
	
	
	/**
	 * Add an item onto the end of the array.
	 * 
	 * @param aItem the item to add.
	 * @throws IllegalArgumentException if the given item is null.
	 */
	public void add(T aItem)
	{
		if (null == aItem)
		{
			throw new IllegalArgumentException("Cannot add a null item");
		}
		
		if (iArray.length == iSize)
		{
			resizeArray(1);
		}
		
		iArray[iSize] = aItem;
		++iSize;
	}
	
	
	
	/**
	 * Add all items from another array onto the end of this array.
	 * 
	 * @param aItems the items to add.
	 * @throws IllegalArgumentException if the given argument is null.
	 */
	public void addAll(DynamicArray<T> aItems)
	{
		if (null == aItems)
		{
			throw new IllegalArgumentException("Cannot add from a null array");
		}
		
		int numItemsToAdd = aItems.size();

		if (0 >= numItemsToAdd)
		{
			return;
		}
		
		int capacityRequired = numItemsToAdd - (iArray.length - iSize);
		
		if (0 < capacityRequired)
		{
			resizeArray( capacityRequired );
		}
		
		for (int i=0; i<numItemsToAdd; ++i)
		{
			iArray[iSize] = aItems.get(i);
			++iSize;
		}
	}
	
	
	/**
	 * Get an {@link Iterator} over this array.
	 * 
	 * @see Iterable#iterator()
	 * @see #getInternalArray()
	 */
	public Iterator<T> iterator()
	{
		return new DynamicArrayIterator<T>(this);
	}	
	
	
	
	/**
	 * Resize the internal array.
	 * 
	 * @param aMinimumExtraCapacityNeeded the minimum amount of extra capacity 
	 * that the resized array should have.
	 */
	private void resizeArray(int aMinimumExtraCapacityNeeded)
	{
		// how many multiples of the increment do we need to increase by
		int inc = iIncrement * 
				(int)Math.ceil((double)aMinimumExtraCapacityNeeded / (double)iIncrement);
		
		Object[] newArray = new Object[iArray.length + inc];
		System.arraycopy(iArray, 0, newArray, 0, iSize);
		iArray = newArray;
	}

	
	
	/**
	 * Remove an item from this array.
	 * @param aIndex the index of the item to remove.
	 * @return the removed item if the specified index is valid; otherwise null.
	 */
	public T remove(int aIndex)
	{
		T item = get(aIndex);
		
		if (null != item)
		{
			// if not removing the very last item
			if (iSize - 1 > aIndex)
			{
				// shift elements back by 1
				System.arraycopy(iArray,aIndex+1,iArray,aIndex,iSize-aIndex-1);
			}
			
			// reduce count
			--iSize;
		}
		
		return item;
	}
	
	
	
	/**
	 * Remove all items from this array.
	 */
	public void clear()
	{
		iSize = 0;
	}
	
	
	
	/**
	 * Get the internal array that actually holds the data.
	 * 
	 * This method is provided for performance reasons.
	 * 
	 * @return the internal data array (non-null). Note that 
	 * although the size of this array may be larger than 
	 * the number reported by {@link #size()} no assumption 
	 * must must be made regarding the content of the extra array spaces.
	 */
	public T[] getInternalArray()
	{
		return (T[])iArray;
	}
	
	


	/**
	 * Iterator for a {@link DynamicArray}.
	 */
	private class DynamicArrayIterator<T> implements Iterator<T>
	{
		private DynamicArray<T> iDynamicArray = null;
		private int iIndex = 0;

		/**
		 * Constructor.
		 * @param aArray the array to iterate over.
		 */
		public DynamicArrayIterator(DynamicArray<T> aArray)
		{
			iDynamicArray = aArray;
		}

		/**
		 * @see Iterator#hasNext()
		 */
		public boolean hasNext()
		{
			return iDynamicArray.size() > iIndex;
		}

		/**
		 * @see Iterator#next()
		 */
		public T next()
		{
			return iDynamicArray.get(iIndex++);
		}

		/**
		 * @see Iterator#remove()
		 */
		public void remove()
		{
			iDynamicArray.remove(iIndex);
		}
	}
	
}


