/**
 * Copyright (C) 2010 Ramesh Nair (www.hiddentao.com)
 * 
 * This is free software: you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) any later version.
 * 
 * This is distributed in the hope that it will  be useful, but WITHOUT ANY 
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this.  If not, see <http://www.gnu.org/licenses/>.
 */

package javax.swing.applet;

import java.applet.AppletContext;
import java.applet.AudioClip;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Locale;

import javax.imageio.ImageIO;
import javax.swing.JFrame;


/**
 * Used by {@link JAppletSimulator} to show the {@link JAbstractApplet} within a normal window.
 * 
 * @author Ramesh Nair 
 */
final class JSimulatedAppletImpl extends JFrame
{
    private URL iCodeBase = null;
    private boolean iAppletIsActive = false;
    private Hashtable iParameters = new Hashtable();
    
    private AppletContext iAppletContext = new JSimulatedAppletContextImpl();
    
    
    public JSimulatedAppletImpl() throws HeadlessException
    {
        super("Applet simulator");
        this.setResizable( false );
        this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    }


    void refreshAppletGui()
    {
        getContentPane().validate();
        repaint();
    }

    
    public Container getContentPane()
    {
        return super.getContentPane();
    }
    
    
    AppletContext getAppletContext()
    {
        return iAppletContext;
    }

    String getAppletInfo()
    {
        return "Applet Simulator";
    }

    AudioClip getAppletAudioClip( URL url, String name )
    {
        return null;
    }

    AudioClip getAppletAudioClip( URL url )
    {
        return null;
    }

    
    void setAppletCodeBase(URL aCodeBase)
    {
        iCodeBase = aCodeBase;
    }
    URL getAppletCodeBase()
    {
        return iCodeBase;
    }
    
    

    URL getAppletDocumentBase()
    {
        return iCodeBase;
    }

    Image getAppletImage( URL url, String name )
    {
        return getAppletImage(url);
    }

    Image getAppletImage( URL url )
    {
        Image img = null;
        try
        {
            img = ImageIO.read( url );
        }
        catch (IOException e)
        {
            e.printStackTrace( System.err );
        }
        return img;
    }

    public Locale getAppletLocale()
    {
        return Locale.UK;
    }

    
    
    void setAppletParameter(String aName, String aValue )
    {
        iParameters.put( aName, aValue );
    }
    String getAppletParameter( String name )
    {
        return (String)iParameters.get(name);
    }

    String[][] getAppletParameterInfo()
    {
        return null;
    }

    
    void setAppletIsActive(boolean aVal)
    {
        iAppletIsActive = aVal;
    }
    boolean isAppletActive()
    {
        return iAppletIsActive;
    }
    

    void playAppletSound( URL url, String name )
    {
    }

    void playAppletSound( URL url )
    {
    }

    void resizeApplet( Dimension d )
    {
        ((JFrame)this).setSize( d );
        refreshAppletGui();
    }

    void resizeApplet( int width, int height )
    {
        ((JFrame)this).setSize( width, height );
        refreshAppletGui();
    }

    void showAppletStatus( String msg )
    {
    }

}


