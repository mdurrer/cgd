/**
 * Copyright (C) 2010 Ramesh Nair (www.hiddentao.com)
 * 
 * This is free software: you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) any later version.
 * 
 * This is distributed in the hope that it will  be useful, but WITHOUT ANY 
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this.  If not, see <http://www.gnu.org/licenses/>.
 */

package javax.swing.applet;

import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AudioClip;
import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;


/**
 * Implementation of {@link AppletContext} for use by {@link JAppletSimulator}.
 * 
 * @author Ramesh Nair 
 */
final class JSimulatedAppletContextImpl implements AppletContext
{
    private static Vector iDummyList = new Vector();
    
    public Applet getApplet( String arg0 )
    {
        return null;
    }

    public Enumeration getApplets()
    {
        return iDummyList.elements();
    }

    public AudioClip getAudioClip( URL arg0 )
    {
        return null;
    }

    public Image getImage( URL arg0 )
    {
        return null;
    }

    public InputStream getStream( String arg0 )
    {
        return null;
    }

    public Iterator getStreamKeys()
    {
        return null;
    }

    public void setStream( String arg0, InputStream arg1 ) throws IOException
    {
    }

    public void showDocument( URL arg0 )
    {
        JAppletSimulator.logInfoMsg( "AppletContext::showDocument: " + arg0 );
    }

    public void showDocument( URL arg0, String arg1 )
    {
        JAppletSimulator.logInfoMsg( "AppletContext::showDocument: " + arg0 + ", " + arg1 );
    }

    public void showStatus( String arg0 )
    {
        JAppletSimulator.logInfoMsg( "AppletContext::showStatus: " + arg0 );
    }

}
