#    Jellyfish Quest
#    Copyright (C) 2009  Ben Whittaker
#
#    Menu and Button classes

import pygame
from pygame.locals import *
#import objects
from levels import *
from base import *

MenuObjs = pygame.sprite.Group()
Buttons = pygame.sprite.Group()
ActiveButton = pygame.sprite.GroupSingle()

class Button(pygame.sprite.Sprite):
    def __init__(s, pos, path, ident):
        pygame.sprite.Sprite.__init__(s)
        s.pos = pos
        s.path = path
        s.ident = ident
        s.sheet = get_image(path, 1)
        size = s.sheet.get_size()
        s.img_off = s.sheet.subsurface((0, 0, size[0] / 2, size[1]))
        s.img_over = s.sheet.subsurface((size[0] / 2, 0, size[0] / 2, size[1]))
        s.image = s.img_off
        s.pos[0] = pos[0] - s.image.get_width() / 2
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.next = ActiveButton.sprite
        s.last = None
        if ActiveButton.sprite <> None:
            ActiveButton.sprite.last = s
        s.add(ActiveButton)
        s.add(Buttons)
        s.add(MenuObjs)
    def update(s, events):
        global return_id
        if ActiveButton in s.groups():
            s.image = s.img_over
            for event in events:
                if event.type == KEYDOWN:
                    if event.key == K_UP and s.last <> None:
                        s.last.add(ActiveButton)
                        s.image = s.img_off
                        return_id = "optionup"
                    elif event.key == K_DOWN and s.next <> None:
                        s.next.add(ActiveButton)
                        s.image = s.img_off
                        return_id = "optiondown"
                    elif event.key in (K_a, K_s, K_SPACE, K_LCTRL, K_RCTRL, K_RSHIFT, K_LSHIFT, K_RETURN):
                        return_id = s.ident

class TextButton(Button):
    def __init__(s, pos, text, color, ident, text2 = None, color2 = None, font = Font, align = 1):
        pygame.sprite.Sprite.__init__(s)
        s.pos = pos
        s.ident = ident
        if text2 == None:
            text2 = text
        if color2 == None:
            color2 = color
        s.img_off = font.render(text, 0, color)
        s.img_over = font.render(text2, 0, color2)
        s.image = s.img_off
        if align == 1:
            s.pos[0] = pos[0] - s.image.get_width() / 2
        elif align == 2:
            s.pos[0] = pos[0] - s.image.get_width()
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.next = ActiveButton.sprite
        s.last = None
        if ActiveButton.sprite <> None:
            ActiveButton.sprite.last = s
        s.add(ActiveButton)
        s.add(Buttons)
        s.add(MenuObjs)

class MultiSelect(Button):
    def __init__(s, pos, textlist, color, identbase, color2 = None, font = Font, itemnum = 0, align = 1):
        pygame.sprite.Sprite.__init__(s)
        s.pos = pos
        s.cpos = list(pos)
        s.textlist = textlist
        s.itemnum = itemnum
        s.color = color
        s.identbase = identbase
        s.ident = identbase + "#"
        if color2 == None:
            s.color2 = color
        else:
            s.color2 = color2
        s.font = font
        s.img_off = s.font.render(s.textlist[s.itemnum], 0, s.color)
        s.img_over = s.font.render(s.textlist[s.itemnum], 0, s.color2)
        s.image = s.img_off
        if align == 1:
            s.pos[0] = pos[0] - s.image.get_width() / 2
        elif align == 2:
            s.pos[0] = pos[0] - s.image.get_width()
        s.align = align
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.next = ActiveButton.sprite
        s.last = None
        if ActiveButton.sprite <> None:
            ActiveButton.sprite.last = s
        s.add(ActiveButton)
        s.add(Buttons)
        s.add(MenuObjs)
    def update(s, events):
        global return_id
        redraw = False
        if ActiveButton.sprite == s:
            for event in events:
                if event.type == KEYDOWN:
                    if event.key == K_RIGHT and s.itemnum < len(s.textlist) - 1:
                        s.itemnum += 1
                        redraw = True
                    if event.key == K_LEFT and s.itemnum > 0:
                        s.itemnum -= 1
                        redraw = True
        if redraw == True:
            s.img_off = s.font.render(s.textlist[s.itemnum], 0, s.color)
            s.img_over = s.font.render(s.textlist[s.itemnum], 0, s.color2)
            s.image = s.img_over
            if s.align == 1:
                s.pos[0] = s.cpos[0] - s.image.get_width() / 2
            elif s.align == 2:
                s.pos[0] = s.cpos[0] - s.image.get_width()
            s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
            return_id = s.identbase + str(s.itemnum)
        Button.update(s, events)

class Text(pygame.sprite.Sprite):
    def __init__(s, pos, text, color, font = Font, align = 1):
        pygame.sprite.Sprite.__init__(s)
        s.pos = pos
        s.image = font.render(text, 0, color)
        if align == 1:
            s.pos[0] = pos[0] - s.image.get_width() / 2
        elif align == 2:
            s.pos[0] = pos[0] - s.image.get_width()
        s.align = align
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.add(MenuObjs)

class Menu:
    def __init__(s, surface, backcolor = (0, 0, 0), background = None):
        s.surface = surface
        s.backcolor = backcolor
        s.background = background
        for obj in MenuObjs.sprites():
            obj.kill()
        s.ypos = 0
    def update(s, events):
        global return_id
        return_id = None
        s.surface.fill(s.backcolor)
        if s.background <> None:
            s.surface.blit(get_image(s.background, 1), (0, 0))
        for sprite in MenuObjs.sprites():
            s.surface.blit(sprite.image, (sprite.pos[0], sprite.pos[1] - s.ypos))
        for sprite in Buttons.sprites():
            sprite.update(events)
            if return_id <> None:
                break
        top = False
        bottom = False
        for sprite in Buttons.sprites():
            if sprite.pos[1] < s.ypos:
                top = True
            if sprite.pos[1] + sprite.image.get_height() - 1 >  s.ypos + screensize[1]:
                bottom = True
        if top == True:
            s.surface.blit(get_image("topscroll.png", 1), (0, 0))
        elif bottom == True:
            s.surface.blit(get_image("bottomscroll.png", 1), (0, screensize[1] - 3))
        a = ActiveButton.sprite
        if a.next <> None:
            nextb = a.next
        else:
            nextb = a
        if nextb.pos[1] + nextb.image.get_height() - 1 > s.ypos + screensize[1]:
            s.ypos += 1
        if a.last <> None:
            lastb = a.last
        else:
            lastb = a
        if lastb.pos[1] < s.ypos:
            s.ypos -= 1
        return s.surface, return_id

def menu_update(events):
    return menuobj.update(events)

def mainmenuinit(gameinprog = False):
    global menuobj
    menuobj = Menu(pygame.Surface(screensize), backcolor = (0, 0, 128))
    if gameinprog == False:
        TextButton([16, 23], "Quit", (159, 159, 255), "quit", color2 = (216, 216, 255))
        TextButton([16, 15], "Options", (159, 159, 255), "options", color2 = (216, 216, 255))
        MultiSelect([16, 8], ["<" + l[0].split("/")[0] + ">" for l in levellist], (159, 159, 255), "level", color2 = (216, 216, 255))
        TextButton([16, 1], "Start", (159, 159, 255), "new game", color2 = (216, 216, 255))
    else:
        Button([16, 24], "endgamebutton.png", "endgame")
        TextButton([16, 16], "Options", (159, 159, 255), "options", color2 = (216, 216, 255))
        TextButton([16, 9], "Continue", (159, 159, 255), "continue", color2 = (216, 216, 255))
        Text([16, 1], "PAUSED", (159, 159, 255))

def optionsmenuinit(settings):
    global menuobj
    menuobj = Menu(pygame.Surface(screensize), backcolor = (0, 0, 128))
    TextButton([16, 28], "Back", (159, 159, 255), "mainmenu", color2 = (216, 216, 255))
    Text([1, 21], "Zoom", (159, 159, 255), align = 0)
    MultiSelect([32, 21], ["<" + str(a) + ">" for a in zoomsizes], (159, 159, 255), "zoom", color2 = (216, 216, 255), itemnum = zoomsizes.index(settings["zoom"]), align = 2)
    Text([1, 14], "Full", (159, 159, 255), align = 0)
    MultiSelect([32, 14], ["<Off>", "<On>"], (159, 159, 255), "fullscreen", color2 = (216, 216, 255), itemnum = settings["fullscreen"], align = 2)
    Text([1, 7], "Sound", (159, 159, 255), align = 0)
    MultiSelect([32, 7], ["<" + str(a) + ">" for a in range(0, 9, 1)], (159, 159, 255), "soundvol", color2 = (216, 216, 255), itemnum = int(settings["soundvol"] * 8), align = 2)
    Text([1, 0], "Music", (159, 159, 255), align = 0)
    MultiSelect([32, 0], ["<" + str(a) + ">" for a in range(0, 9, 1)], (159, 159, 255), "musicvol", color2 = (216, 216, 255), itemnum = int(settings["musicvol"] * 8), align = 2)
##def pausemenuinit():
##    global menuobj
##    menuobj = Menu(pygame.Surface(screensize), backcolor = (0, 0, 128))
##    Button((1, 16), "endgamebutton.png", "endgame")
##    TextButton((2, 6), "Continue", (159, 159, 255), "continue", color2 = (216, 216, 255))

def leveltitleinit(levelnum):
    global menuobj
    menuobj = Menu(pygame.Surface(screensize), backcolor = (0, 0, 128))
    lvltext = levellist[levelnum][0].split("/")
    y = 1
    for string in lvltext:
        Text([16, y], string, (159, 159, 255))
        y += 7
    TextButton([16, 24], "START", (159, 159, 255), "continue", color2 = (216, 216, 255))

def deathscreeninit(progstate):
    global menuobj
    menuobj = Menu(pygame.Surface(screensize), backcolor = (0, 0, 0))
    TextButton([16, 4], "YOU DIED", (159, 0, 0), "restartlevel")
    Text([16, 13], "LIVES:" + str(progstate["lives"]), (159, 0, 0))
    Text([16, 21], "SCORE:" + str(progstate["score"]), (159, 0, 0))

def gameoverinit(progstate):
    global menuobj
    menuobj = Menu(pygame.Surface(screensize), backcolor = (0, 0, 0))
    TextButton([16, 4], "GAME", (159, 0, 0), "endgame")
    Text([16, 11], "OVER", (159, 0, 0))
    Text([16, 20], "SCORE:" + str(progstate["score"]), (159, 0, 0))
