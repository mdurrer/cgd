/----------------------------------------------------------------------------\
|                                                                            |
|          ##############  ##  ##            ##  ##          ##              |
|              ##          ##  ##          ##                ##              |
|              ##    ##    ##  ##          ##    ##    ####  ##              |
|              ##  ##  ##  ##  ##          ####  ##  ##      ####            |
|          ##  ##  ######  ##  ##  ##  ##  ##    ##    ##    ##  ##          |
|          ##  ##  ##      ##  ##  ##  ##  ##    ##      ##  ##  ##          |
|            ##      ####  ##  ##  ##  ##  ##    ##  ####    ##  ##          |
|                                    ####                                    |
|                                  ####                                      |
|                ######                                      ##              |
|              ##      ##                                    ##              |
|            ##          ##                                ######            |
|            ##          ##                                  ##              |
|            ##          ##                                  ##              |
|            ##          ##  ##    ##      ####        ####  ##              |
|            ##          ##  ##    ##    ##    ##    ##      ##              |
|            ##    ##  ##    ##    ##    ######    ##  ##  ####              |
|              ##    ##      ##    ##  ####      ##      ##  ##              |
|                ####  ####    ####  ##    ######    ####      ##            |
|                                                                            |
\----------------------------------------------------------------------------/
------------------------------------------------------------------------------
                              Jellyfish Quest 0.2
                       Copyright (C) 2009 Ben Whittaker
                           bend.whittaker@gmail.com
------------------------------------------------------------------------------
------------------------------------------------------------------------------
Gameplay:
------------------------------------------------------------------------------
Use the arrow keys to move.
Hold down the A key to reel in your tentacles.
Hold down the S key to grab stuff with the tip of your tentacles.

Reel your tentacles all the way in while holding a fish or enemy in order to eat it.
 - Eating stuff heals you, but it also fills your stomach.
 - You can not eat if you are too full.

Touch enemies with the tip of your tentacles to temporarily stun them.

Collect bonusses (shiny gold things) by touching them (with your body, not your tentacles).
 - You get a life for every four bonusses you collect.
 - Your score is equal to the amount you collect in the entire game.

The red bar in the upper left is your health.
The green bar is how full your stomach is.
The yellow bar is how close you are to getting another life.

------------------------------------------------------------------------------
To Win:
------------------------------------------------------------------------------
The goal of the game is to rescue your girlfriend, Ambrosia, who has been captured by Japanese fishermen. Working toward this end goal is generally accomplished by getting to the far right of each level, defeating each boss, and triggering the occasional bit of wanton destruction. Your game is scored by how many bonusses you collect, of which there are four in each level.

------------------------------------------------------------------------------
Misc. Help:
------------------------------------------------------------------------------
You can scale the window size by pressing the + or - keys.

An FPS counter will show in the bottom-right corner if you press TAB at any time. The optimum FPS is 40, if it's much below that performance can generally be improved by scaling the window down, or occasionally by going into (or out of) fullscreen.

------------------------------------------------------------------------------
Credits:
------------------------------------------------------------------------------
Code, art, design, writing, etc.:
	Ben Whittaker

Music:
	island (daytime) by conner honest
	taken from <http://8bc.org/members/conner+honest/>

Font:
	Picopixel v1.1
	made by Sebastian Weber

Sound FX were all made using either sfxr or as3sfxr.

------------------------------------------------------------------------------
License:
------------------------------------------------------------------------------
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

