#   The level generation functions and various related functions

#   Jellyfish Quest
#   Copyright (C) 2009 Ben Whittaker

import pygame
from pygame.locals import *
import math

from base import *
from objects import *

##def baywaves(frames, level, para):
##    pointlist = []
##    for x in range(int(((env.boundries[0] - screensize[0]) * para + screensize[0]) / 2 + 1)):
##        x *= 2
##        y = (math.sin((x * para + frames / 2) * math.pi / 32) + math.sin((x * para - frames / 4) * math.pi / 16) / 2) * para + env.waterlevel
##        pointlist += [[x, y]]
##    return pointlist

def rightedgewin():
    if PlayerGroup.sprite <> None:
        if PlayerGroup.sprite.pos[0] >= env.boundries[0] - 0.5:
            return True
    return False

baywavecache = {}
def baywaves(x, frames):
    x = int(x)
    #frames = int(frames)
    ident = (x % 64, frames % 128)
    if ident not in baywavecache:
        baywavecache[ident] =  math.sin((x + frames / 2) * math.pi / 32) + math.sin((x - frames / 4) * math.pi / 16) / 2
        #print len(baywavecache)
    return baywavecache[ident]

def testlevel():
    mainlayer = ParaLayer(mask = "Mock_Jellyfish_Level-mask.png", pos = [-8, -8])
    layers = [
        ParaLayer(parallax = 0.001, image = "Beach_Back0.png", water = True),
        ParaLayer(parallax = 2**-3.5, water = True),
        ParaLayer(parallax = 0.125, image = "Beach_Back1.png"),# water = True),
        ParaLayer(parallax = 2**-2.5, water = True),
        ParaLayer(parallax = 2**-1.5, water = True),
        ParaLayer(parallax = 2**-0.5, water = True),
        ParaLayer(image = "Mock_Jellyfish_Level-ground.png", water = True),
        mainlayer,
        ParaLayer(image = "Mock_Jellyfish_Level-foreground.png", water = True)
        ]
    p = Player([12, 12], keyset, mainlayer)
    distribute(10, Rock, mainlayer, (0, 0), (288, 96))
    for a in range(2):
        Jellyfish([45, 45], mainlayer)
        Jellyfish([100, 30], mainlayer)
    Crab([270, 30], mainlayer)
    Crab([165, 0], mainlayer)
    MadUrch([70, 40], mainlayer)
    Frog([160, 10], mainlayer)
    for a in range(30):
        Fish([random.randrange(0, 140), random.randrange(30, 60)], mainlayer)
    for a in range(3):
        SaberFish([random.randrange(0, 140), random.randrange(30, 60)], mainlayer)
    env.init(layers, 18, (0, 0, 150, 50), baywaves, (288, 96))
    playmusic("Mozart_Piano_Sonata_Amin3.ogg")

def level1_1():
    mainlayer = ParaLayer(mask = "1-1mask.png", pos = [-8, -8])
    layers = [
        ParaLayer(parallax = 0.001, image = "Beach_Back0.png", water = True),
        #ParaLayer(parallax = 2**-6.5, water = True),
        #ParaLayer(parallax = 2**-5.5, water = True),
        #ParaLayer(parallax = 2**-4.5, water = True),
        ParaLayer(parallax = 0.0625, image = "Beach_Back1.png"),
        ParaLayer(parallax = 2**-3.5, water = True),
        ParaLayer(parallax = 2**-2.5, water = True),
        ParaLayer(parallax = 2**-1.5, water = True),
        ParaLayer(parallax = 2**-0.5, water = True),
        ParaLayer(image = "1-1ground.png", water = True),
        mainlayer,
        ParaLayer(image = "1-1foreground.png", water = True)
        ]
    Static([53, 23], "1-1waterfall-a.png", [28, 27], layers[-3], 5)
    LillyPad([137, 40], (140, 45), layers[-3])
    Static([41, 21], "1-1waterfall-b.png", [26, 27], layers[-1], 5)
    LillyPad([157, 40], (160, 45), layers[-1])
    LillyPad([174, 40], (178, 48), layers[-1])
    Rock([250, 100], mainlayer, size = 1)
    Rock([238, 100], mainlayer, size = 0)
    Rock([395, 89], mainlayer, size = 0)
    Rock([393, 85], mainlayer, size = 1)
    Rock([393, 90], mainlayer, size = 2)
    Rock([82, 80], mainlayer, size = 0)
    distribute(75, Fish, mainlayer, (0, 45), (544, 160))
    distribute(5, Jellyfish, mainlayer, (0, 45), (544, 160))
    distribute(3, SaberFish, mainlayer, (100, 45), (544, 160))
    Crab([300, 125], mainlayer)
    Crab([500, 100], mainlayer)
    Frog([205, 75], mainlayer)
    MadUrch([183, 100], mainlayer)
    Bonus([28, 121], mainlayer)
    Bonus([233, 92], mainlayer)
    Bonus([447, 60], mainlayer)
    Clam([338, 127], mainlayer, childtype = "bonus")
    Clam([485, 102], mainlayer)
    Clam([140, 121], mainlayer)
    Player([70, 50], keyset, mainlayer)
    env.init(layers, 44, (0, 0, 150, 50), baywaves, (544, 160), rightedgewin)
    playmusic("04 - island (daytime).ogg")

def level1_2():
    mainlayer = ParaLayer(mask = "1-2mask.png", pos = [-8, -8])
    layers = [
        ParaLayer(parallax = 0.001, image = "Beach_Back0.png", water = True),
        #ParaLayer(parallax = 0.0625, image = "Beach_Back1.png"),
        ParaLayer(parallax = 2**-3.5, water = True),
        ParaLayer(parallax = 2**-2.5, water = True),
        ParaLayer(parallax = 2**-1.5, water = True),
        ParaLayer(parallax = 2**-0.5, water = True),
        ParaLayer(image = "1-2ground.png", water = True),
        mainlayer,
        ParaLayer(image = "1-2foreground.png", water = True)
        ]
    Rock([87, 67], mainlayer, size = 2)
    Rock([95, 67], mainlayer, size = 1)
    Rock([225, 65], mainlayer, size = 1)
    Rock([249, 65], mainlayer, size = 0)
    Rock([255, 65], mainlayer, size = 0)
    Rock([323, 157], mainlayer, size = 1)
    Inert([186, 75], 3, 100, "pickaxe.png", mainlayer, groups = [Grabbables, HardBodies])
    #Inert([372, -5], 0.125, 50, "1-2cage.png", mainlayer, groups = [HardBodies])
    LiftCage([371.5, 65], mainlayer)
    distribute(50, Fish, mainlayer, (0, 45), (416, 224))
    distribute(10, SaberFish, mainlayer, (0, 45), (416, 224))
    Clam([266, 190], mainlayer)
    Clam([347, 90], mainlayer)
    Clam([167, 75], mainlayer)
    MadUrch([84, 63], mainlayer)
    MadUrch([238, 60], mainlayer)
    MadUrch([253, 199], mainlayer)
    Crab([295, 200], mainlayer)
    Crab([175, 170], mainlayer)
    Frog([125, 60], mainlayer)
    Bonus([122, 119], mainlayer)
    Bonus([180, 77], mainlayer)
    Bonus([143, 168], mainlayer)
    Bonus([361, 198], mainlayer)
    Player([6, 60], keyset, mainlayer)
    env.init(layers, 44, (0, 0, 150, 50), baywaves, (416, 224), rightedgewin)
    playmusic("04 - island (daytime).ogg")

levellist = [("Lvl 1-1/Jellyfish/Bay", level1_1), ("Lvl 1-2/Mind the/Coral", level1_2), ("Lvl Tst/TestLvl", testlevel)]
