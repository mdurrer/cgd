#! /usr/bin/env python
# The above line makes this executible in unix systems

#    Jellyfish Quest 0.2
#    Copyright (C) 2009  Ben Whittaker
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import pygame
pygame.init()
from pygame.locals import *
import os
import sys

try:
    os.chdir(sys.argv[0][:sys.argv[0].rindex("JellyfishQuest.py")])
except:
    pass

from base import *
from objects import *
from menu import *
from levels import *

def set_screen(zoom = None, fullscreen = None):
    global scale
    if zoom <> None:
        get_settings()["zoom"] = zoom
    scale = get_settings()["zoom"]
    if fullscreen <> None:
        get_settings()["fullscreen"] = fullscreen
    else:
        fullscreen = get_settings()["fullscreen"]
    size = (screensize[0] * scale, screensize[1] * scale)
    if fullscreen == False:
        screen = pygame.display.set_mode(size)
        pygame.mouse.set_visible(True)
    else:
        #while size[0] > pygame.display.list_modes()[0][0] or size[1] > pygame.display.list_modes()[0][1]:
            #get_settings()["zoom"] //= 2
            #zoom = get_settings()["zoom"]
            #size = (screensize[0] * zoom, screensize[1] * zoom)
        scale = pygame.display.list_modes()[-1][1] / screensize[1]
        size = (screensize[0] * scale, screensize[1] * scale)
        screen = pygame.display.set_mode(size, pygame.FULLSCREEN)
        pygame.mouse.set_visible(False)
    pygame.display.set_caption(caption + " " + str(get_settings()["zoom"]) + "00%")
    return screen
def zoomin():
    zoom = get_settings()["zoom"]
    index = zoomsizes.index(zoom)
    if index + 1 < len(zoomsizes):
        zoom = zoomsizes[index + 1]
    return set_screen(zoom)
def zoomout():
    zoom = get_settings()["zoom"]
    index = zoomsizes.index(zoom)
    if index > 0:
        zoom = zoomsizes[index - 1]
    return set_screen(zoom)

caption = "Jellyfish Quest"
#zoom = 8
zoomtype = 0
icon = pygame.image.load("icon.png")
pygame.display.set_icon(icon)
#screen = pygame.display.set_mode((screensize[0] * zoom, screensize[1] * zoom))
#pygame.display.set_caption(caption + " " + str(zoom) + "00%")
load_settings()
scale = get_settings()["zoom"]
screen = set_screen()

class Camera:
    def __init__(s, surface, backcolor = (0, 0, 0), pos = [0, 0], objgroup = None):
        s.surface = surface
        s.backcolor = backcolor
        s.pos = pos
        s.objgroup = objgroup
    def draw(s):
        if s.objgroup <> None and s.objgroup.sprite <> None:
            obj = s.objgroup.sprite
            x = int(obj.pos[0]) + obj.rect.width // 2 - s.surface.get_width() // 2 + obj.camerarel[0]
            y = int(obj.pos[1]) + obj.rect.height // 2 - s.surface.get_height() // 2 + obj.camerarel[1]
            #s.pos[0] -= (s.pos[0] - x) / 5
            #s.pos[1] -= (s.pos[1] - y) / 5
            s.pos[0] = x
            s.pos[1] = y
            if s.pos[0] < 0:
                s.pos[0] = 0
            elif s.pos[0] + screensize[0] > env.boundries[0]:
                s.pos[0] = env.boundries[0] - screensize[0]
            if s.pos[1] < 0:
                s.pos[1] = 0
            elif s.pos[1] + screensize[1] > env.boundries[1]:
                s.pos[1] = env.boundries[1] - screensize[1]
            setmicpos(tuple(obj.pos))
        s.surface.fill(s.backcolor)
        for paralayer in env.paralayers:
            paralayer.draw(s.surface, [int(s.pos[0]), int(s.pos[1])])
            #x = spr.pos[0] - s.pos[0]
            #y = spr.pos[1] - s.pos[1]
            #s.surface.blit(spr.image, (x, y))
        if PlayerGroup.sprite <> None:
            s.surface.blit(get_image("hud.png", 1), (0, 0))
            h = PlayerGroup.sprite.health
            pygame.draw.line(s.surface, (255, 0, 0), (-1, 0), (int(h) - 1, 0))
            if h % 1 <> 0 and h > 0:
                s.surface.set_at((int(h), 0), (int((h % 1) * 255), 0, 0))
            f = PlayerGroup.sprite.fullness
            pygame.draw.line(s.surface, (0, 255, 0), (-1, 1), (int(f) - 1, 1))
            if f % 1 <> 0 and f > 0:
                s.surface.set_at((int(f), 1), (0, int((f % 1) * 255), 0))
            b = get_progstate()["bonusmeter"]
            pygame.draw.line(s.surface, (255, 255, 0), (-1, 2), (int(b) - 1, 2))
        return s.surface

def main():
    global screen
    #global zoom
    global scale
    global game_mode
    global paralayers
    global musicvol
    running = 1
    game_mode = "title"
    screen.fill((0, 0, 255))
    clock = pygame.time.Clock()
    #paralayers += [Layer(background = "Mock_Jellyfish_Level-ground.png", foreground = "Mock_Jellyfish_Level-foreground.png")]
    #for a in range(10):
    #    Jellyfish([10, 10], [paralayers[0]])
    #    Jellyfish([15, 15], [paralayers[0]])
    #p = Player([12, 12], keyset, [paralayers[0]])
    cam = Camera(pygame.Surface(screensize), backcolor = (0, 255, 255), pos = [0, 0], objgroup = PlayerGroup)
    show_fps = False
    #testlevel()
    #level1_1()
    #cam.objgroup = CamFocus
    gameinprog = False
    menupart = None
    oldmenupart = None
    fps = 0.0
    faderate = 1
    while running == 1:
        fps = (fps + 1000 / clock.tick(80 - fps)) / 2
        keys = pygame.key.get_pressed()
        events = pygame.event.get()
        for event in events:
            if event.type == QUIT:
                running = 0
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    if game_mode == "menu" and menupart == "mainmenu":
                        game_mode = "title"
                    elif game_mode == "title":
                        running = 0
                    else:
                        #pausemenuinit()
                        mainmenuinit(gameinprog)
                        game_mode = "menu"
                        oldmenupart = menupart
                        menupart = "mainmenu"
                if event.key == K_p and game_mode == "game":
                        #pausemenuinit()
                        mainmenuinit(gameinprog)
                        oldmenupart = menupart
                        menupart = "mainmenu"
                        game_mode = "menu"
                if event.key == K_MINUS:
                    #zoom //= 2
                    #screen = pygame.display.set_mode((screensize[0] * zoom, screensize[1] * zoom))
                    #pygame.display.set_caption(caption + " " + str(zoom) + "00%")
                    screen = zoomout()
                if event.key == K_EQUALS:
                    #zoom *= 2
                    #screen = pygame.display.set_mode((screensize[0] * zoom, screensize[1] * zoom))
                    #pygame.display.set_caption(caption + " " + str(zoom) + "00%")
                    screen = zoomin()
                if event.key == K_TAB:
                    if show_fps == False:
                        show_fps = True
                    else:
                        show_fps = False
        if game_mode == "title":
            gameinprog = False
            reset_progstate()
            env.kill()
            playmusic("04 - island (daytime).ogg")
            rawscreen = get_image("title.png")
            for event in events:
                if event.type == KEYDOWN and event.key not in (K_MINUS, K_EQUALS, K_ESCAPE, K_LALT, K_RALT):
                    mainmenuinit()
                    game_mode = "menu"
                    menupart = "mainmenu"
        elif game_mode == "menu":
            rawscreen, button_id = menu_update(events)
            if button_id == "new game" or button_id == "level#":
                levellist[get_progstate()["levelnum"]][1]()
                leveltitleinit(get_progstate()["levelnum"])
                menupart = "leveltitle"
                game_mode = "menu"
                gameinprog = True
            elif button_id == "mainmenu":
                mainmenuinit(gameinprog)
                menupart = "mainmenu"
                game_mode = "menu"
            elif button_id == "options":
                optionsmenuinit(get_settings())
                game_mode = "menu"
            elif button_id == "continue":
                if oldmenupart == "leveltitle":
                    leveltitleinit(get_progstate()["levelnum"])
                    menupart = "leveltitle"
                elif oldmenupart == "deathscreen":
                    deathscreeninit(get_progstate())
                    menupart = "deathscreen"
                elif oldmenupart == "gameover":
                    gameoverinit(get_progstate())
                    menupart = "gameover"
                else:
                    game_mode = "game"
                oldmenupart = None
            elif button_id == "restartlevel":
                levellist[get_progstate()["levelnum"]][1]()
                leveltitleinit(get_progstate()["levelnum"])
                menupart = "leveltitle"
                game_mode = "menu"
                faderate = 1
            elif button_id == "endgame":
                game_mode = "title"
            elif button_id <> None and "level" in button_id:
                get_progstate()["levelnum"] = int(button_id[5:])
            elif button_id <> None and "musicvol" in button_id and "#" not in button_id:
                get_settings()["musicvol"] = float(button_id[8:]) / 8
                pygame.mixer.music.set_volume(get_settings()["musicvol"])
            elif button_id <> None and "soundvol" in button_id and "#" not in button_id:
                setsoundvol(float(button_id[8:]) / 8)
                playsound("bonus.wav")
            elif button_id <> None and "fullscreen" in button_id and "#" not in button_id:
                set_screen(fullscreen = int(button_id[10:]))
            elif button_id <> None and "zoom" in button_id and "#" not in button_id:
                set_screen(zoom = zoomsizes[int(button_id[4:])])
            elif button_id == "quit":
                running = 0
            if game_mode == "menu" and menupart == "mainmenu":
                faderate = 1
        elif game_mode == "game":
            menupart = None
            Objs.update()
            PlayerGroup.sprite.control(keys)
            PlayerGroup.sprite.dmgcheck(pygame.sprite.spritecollide(PlayerGroup.sprite, Harmfulls, False))
            PlayerGroup.sprite.bonuscheck(pygame.sprite.spritecollide(PlayerGroup.sprite, Bonusses, False))
            for sprite in QuasiBodies.sprites():
                sprites2 = pygame.sprite.spritecollide(sprite, HardBodies, False)
                for sprite2 in sprites2:
                    sprite.collphysics(sprite2)
            #screen.fill((0, 0, 255))
            #Objs.draw(screen)
            rawscreen = cam.draw()
            if env.wincond <> None and env.wincond():
                get_progstate()["levelnum"] += 1
                env.kill()
                levellist[get_progstate()["levelnum"]][1]()
                leveltitleinit(get_progstate()["levelnum"])
                menupart = "leveltitle"
                game_mode = "menu"
            if PlayerGroup.sprite.health <= 0:
                if get_progstate()["lives"] <= 0:
                    gameoverinit(get_progstate())
                    menupart = "gameover"
                else:
                    get_progstate()["score"] -= PlayerGroup.sprite.scoregained
                    get_progstate()["lives"] -= 1
                    deathscreeninit(get_progstate())
                    menupart = "deathscreen"
                faderate = 0.05
                env.kill()
                game_mode = "menu"
        scaledscreen = rawscreen
        for a in range(zoomtype):
            if a == int(math.log(scale, 2)):
                break
            scaledscreen = pygame.transform.scale2x(scaledscreen)
        scaledscreen = pygame.transform.scale(scaledscreen, (screensize[0] * scale, screensize[1] * scale))
        if faderate <> 1:
            scaledscreen.set_alpha(int(faderate * 255))
        screen.blit(scaledscreen, (0, 0))
        if show_fps == True:
            fps_text = Font.render(str(int(fps)), 0, (255, 255, 0))
            screen.blit(fps_text, (screensize[0] * scale - fps_text.get_width(), screensize[1] * scale - fps_text.get_height()))
        pygame.display.flip()
#import cProfile as profile
#profile.run('main()')
main()
pygame.quit()
for sprite in MenuObjs.sprites() + Objs.sprites():
    sprite.kill()
save_settings()


# human specific gravity 1.06
