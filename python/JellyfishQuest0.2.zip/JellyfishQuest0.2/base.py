#   Basic functions & variables used by multiple modules

#   Jellyfish Quest
#   Copyright (C) 2009 Ben Whittaker

import pygame
from pygame.locals import *
import os
import math

airdensity = 0.0012
waterdensity = 1
gravity = 0.025
screensize = [32, 32]
zoomsizes = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32]

keyset = {"UP":K_UP, "LEFT":K_LEFT, "RIGHT":K_RIGHT, "DOWN":K_DOWN, "B1":K_a, "B2":K_s}

Font = pygame.font.Font("Picopixel_v1.1.ttf", 8)

defaultprogstate = {"score":0, "bonusmeter":0, "lives":3, "levelnum":0}
progstate = dict(defaultprogstate)

def get_progstate():
    return progstate
def reset_progstate():
    global progstate
    progstate = dict(defaultprogstate)

defaultsettings = {"musicvol":0.5, "soundvol":0.75, "zoom":4, "fullscreen":0}
settingtypes = {"musicvol":"float", "soundvol":"float", "zoom":"int", "fullscreen":"int"}

def load_settings():
    global settings
    settings = dict(defaultsettings)
    keys = settings.iterkeys()
    if os.access("settings.txt", os.F_OK) == True:
        settings_file = open("settings.txt", "r")
        for line in settings_file.readlines():
            line = line.split(":", 1)
            if line[0] in keys:
                if settingtypes[line[0]] == "float":
                    settings[line[0]] = float(line[1])
                elif settingtypes[line[0]] == "int":
                    settings[line[0]] = int(line[1])
        settings_file.close()

def save_settings():
    settings_file = open("settings.txt", "w")
    for key in settings.iterkeys():
        settings_file.write(key + ":" + str(settings[key]) + "\n")
    settings_file.close()

def get_settings():
    return settings

images = {}
def get_image(path, colorkey = 0):
    path = "images/" + path
    if path not in images:
        images[path] = pygame.image.load(path).convert()
        if colorkey == 1:
            images[path].set_colorkey((255, 255, 255))
    return images[path].copy()

sounds = {}
soundpos = {}
micpos = [0, 0]
def playsound(path, volume = 1, pos = None):
    path = "sound/" + path
    if path not in sounds:
        if os.access(path, os.F_OK) == True:
            sounds[path] = pygame.mixer.Sound(path)
            sounds[path].set_volume(settings["soundvol"])
            soundpos[path] = pos
        else:
            sounds[path] = None
            print "'" + path + "' not found."
    if sounds[path] <> None:
        distance = 0
        if pos <> None:
            distance = math.hypot(pos[0] - micpos[0], pos[1] - micpos[1])
        if distance > 100:
            distance = 100
        channel = None
        chanvol = volume * (100.0 - distance) / 100
        if chanvol > 0.1:
            channel = sounds[path].play()
            if channel <> None:
                channel.set_volume(chanvol)
        return channel
    return None
def setmicpos(pos):
    global micpos
    micpos = pos
def setsoundvol(vol):
    settings["soundvol"] = vol
    for a in sounds:
        if sounds[a] <> None:
            sounds[a].set_volume(settings["soundvol"])

currentmusic = None
def playmusic(path, restart = False):
    global currentmusic
    path = "music/" + path
    if currentmusic <> path:
        if os.access(path, os.F_OK) == True:
            pygame.mixer.music.load(path)
            pygame.mixer.music.play(-1)
            pygame.mixer.music.set_volume(settings["musicvol"])
            currentmusic = path
        else:
            print "'" + path + "' not found."
            pygame.mixer.music.stop()
            currentmusic = path
    elif restart == True:
        pygame.mixer.music.play(-1)
        pygame.mixer.music.set_volume(settings["musicvol"])

