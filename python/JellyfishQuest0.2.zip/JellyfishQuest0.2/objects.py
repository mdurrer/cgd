#   The Obj class and various subclasses, and also the ParaLayer class

#   Jellyfish Quest
#   Copyright (C) 2009 Ben Whittaker

import pygame
from pygame.locals import *
import random
import math

from base import *

Objs = pygame.sprite.Group()
#LayeredSprites = pygame.sprite.LayeredUpdates()
PlayerGroup = pygame.sprite.GroupSingle()
Harmfulls = pygame.sprite.Group()
Stingables = pygame.sprite.Group()
Grabbables = pygame.sprite.Group()
Edibles = pygame.sprite.Group()
Bubbling = pygame.sprite.Group()
Bonusses = pygame.sprite.Group()
HardBodies = pygame.sprite.Group()
QuasiBodies = pygame.sprite.Group()
CamFocus = pygame.sprite.GroupSingle()
paralayers = []

def get_at_tol(mask, pos, pos2 = (0, 0)):
    size = mask.get_size()
    if 0 <= pos[0] - pos2[0] < size[0] and 0 <= pos[1] - pos2[1] < size[1]:
        return mask.get_at((pos[0] - pos2[0], pos[1] - pos2[1]))
    else:
        return 0

def distribute(num, obj, paralayer, bound1, bound2):
    while 1:
        if num == 0:
            break
        pos = [random.randrange(bound1[0], bound2[0]), random.randrange(bound1[1], bound2[1])]
        if get_at_tol(paralayer.mask, pos, paralayer.pos) == False:
            obj(pos, paralayer)
            num -= 1

class Static(pygame.sprite.Sprite):
    def __init__(s, pos, sheet, size, paralayer, animspeed = 10, alpha = None, groups = []):
        pygame.sprite.Sprite.__init__(s, groups + [Objs, paralayer])
        s.pos = pos
        s.sheet = get_image(sheet, 1)
        s.sheet.set_alpha(alpha)
        s.size = size
        s.animseq = [s.sheet.subsurface((x, 0, size[0], size[1])) for x in range(0, s.sheet.get_width(), size[0])]
        s.paralayer = paralayer
        s.animspeed = animspeed
        s.framecount = 0
        s.framenum = 0
        s.image = s.animseq[0]
    def update(s):
        s.framecounter(s.animspeed, s.animseq)
    def framecounter(s, length, seq):
        s.framecount += 1
        if s.framecount >= length:
            s.framecount = 0
            s.framenum += 1
            if s.framenum >= len(seq):
                s.framenum = 0
            s.image = seq[s.framenum]
    def draw(s, surface, screenpos):
        if pygame.Rect(screenpos, s.image.get_size()).colliderect(surface.get_rect()):
            surface.blit(s.image, screenpos)

class Obj(Static):
    def __init__(s, pos, density, weight, drag, sheet, paralayer, groups = []): #Density is with water as 1, I think Weight is in really small Kilos, and drag is pure fudge.
        #global images
        pygame.sprite.Sprite.__init__(s, groups + [Objs, paralayer, QuasiBodies])
        s.pos = pos
        s.speed = [0,0]
        #if sheet not in images:
        #    images[sheet] = pygame.image.load(sheet).convert()
        #    images[sheet].set_colorkey((255, 255, 255))
        s.sheet = get_image(sheet, 1)
        s.density = density
        s.weight = weight
        s.drag = drag
        s.friction = 0.5
        s.landslip = True
        s.paralayer = paralayer
        s.collflags = [0, 0, 0, 0]
        s.submerged = False
        s.camerarel = [0, 0]
        s.framecount = 0
        s.framenum = -1
        s.harm = 0
        s.stuntime = 0
        s.stuntimer = 0
    def frictionmath(s, i):
        s.friction
        if s.speed[i] > 0 and s.speed[i] - s.friction >= 0:
            s.speed[i] -= s.friction
        elif s.speed[i] < 0 and s.speed[i] + s.friction <= 0:
            s.speed[i] += s.friction
        else:
            s.speed[i] = 0
    def collphysics(s, obj): #in prog!
        if obj == s:
            return
        flagmaps = ((1, 0), (0, 1), (-1, 0), (0, -1))
        spint = [int(s.pos[0]), int(s.pos[1])]
        opint = [int(obj.pos[0]), int(obj.pos[1])]
        relpos = [opint[0] - spint[0], opint[1] - spint[1]]
        if obj == s.paralayer:
            relspd = [-s.speed[0], -s.speed[1]]
            sprop = 0
        else:
            relspd = [obj.speed[0] - s.speed[0], obj.speed[1] - s.speed[1]]
            sprop = float(s.weight) / (s.weight + obj.weight)
        oprop = 1 - sprop
        #sprop = 1
        #oprop = 0
        loops = 5
        while s.mask.overlap_area(obj.mask, relpos) <> 0:
            bestcollval = 10000
            bestside = None
            for n in range(4):
                collval = s.mask.overlap_area(obj.mask, (relpos[0] + flagmaps[n][0], relpos[1] + flagmaps[n][1]))
                if collval < bestcollval:
                    bestcollval = collval
                    bestside = n
                elif bestcollval == collval:
                    if n in (0, 2) and abs(relspd[1]) > abs(relspd[0]):
                        bestcollval = collval
                        bestside = n
                    elif n in (1, 3) and abs(relspd[0]) > abs(relspd[1]):
                        bestcollval = collval
                        bestside = n
##            if bestside == None:
##                break
##            if obj == s.paralayer:
##                spdpropx = 1
##            elif abs(s.speed[0]) + abs(obj.speed[0]) <> 0:
##                spdpropx = abs(s.speed[0]) / (abs(s.speed[0]) + abs(obj.speed[0]))
##            else:
##                spdpropx = 0.5
            bstsd = flagmaps[bestside]
            if bstsd[0] <> 0:
                i = 0
            if bstsd[1] <> 0:
                i = 1
            shftprop = 0.5
            if obj == s.paralayer:
                shftprop = 1
            else:
                if s.speed[i] * bstsd[i] > 0:
                    shftprop += 0.5
                if obj.speed[i] * bstsd[i] < 0:
                    shftprop -= 0.5
            if shftprop == 0.5:
                shftprop = oprop
            s.pos[i] -= bstsd[i] * shftprop
            obj.pos[i] += bstsd[i] * (1 - shftprop)
##            if obj == s.paralayer:
##                spdpropy = 1
##            elif abs(s.speed[1]) + abs(obj.speed[1]) <> 0:
##                spdpropy = abs(s.speed[1]) / (abs(s.speed[1]) + abs(obj.speed[1]))
##            else:
##                spdpropy = 0.5
            if relspd[i] > 0 > bstsd[i] or relspd[i] < 0 < bstsd[i]:
                s.speed[i] += relspd[i] * oprop
                if obj <> s.paralayer:
                    obj.speed[i] -= relspd[i] * sprop
##            elif relspd[1] > 0 > flagmaps[bestside][1] or relspd[1] < 0 < flagmaps[bestside][1]:
##                s.speed[1] += relspd[1] * oprop
##                if obj <> s.paralayer:
##                    obj.speed[1] -= relspd[1] * sprop
            if obj == s.paralayer:
                relspd = [-s.speed[0], -s.speed[1]]
            else:
                relspd = [obj.speed[0] - s.speed[0], obj.speed[1] - s.speed[1]]
                obj.collflags[bestside - 2] = True
            if abs(relspd[i-1]) > s.friction:
                s.speed[i-1] += relspd[i-1] / abs(relspd[i-1]) * s.friction * oprop
            else:
                s.speed[i-1] += relspd[i-1] * oprop
##            if abs(relspd[0]) > s.friction:
##                s.speed[0] += relspd[0] / abs(relspd[0]) * s.friction * oprop
##            else:
##                s.speed[0] += relspd[0] * oprop
            if obj <> s.paralayer:
                if abs(relspd[i-1]) > obj.friction:
                    obj.speed[i-1] -= relspd[i-1] / abs(relspd[i-1]) * obj.friction * sprop
                else:
                    obj.speed[i-1] -= relspd[i-1] * sprop
##		if abs(relspd[0]) > obj.friction:
##		    obj.speed[0] -= relspd[0] / abs(relspd[0]) * s.friction * sprop
##		else:
##		    obj.speed[0] -= relspd[0] * sprop
            loops -= 1
            if loops == 0:
                break
            spint = [int(s.pos[0]), int(s.pos[1])]
            opint = [int(obj.pos[0]), int(obj.pos[1])]
            relpos = [opint[0] - spint[0], opint[1] - spint[1]]
            s.collflags[bestside] = True
            if obj == s.paralayer:
                relspd = [-s.speed[0], -s.speed[1]]
            else:
                relspd = [obj.speed[0] - s.speed[0], obj.speed[1] - s.speed[1]]
                obj.collflags[bestside - 2] = True
##    def groundcheck(s):
##        posfg = [int(s.pos[0]), int(s.pos[1])]
##        cc = s.paralayer.groundmask.overlap_area(s.mask, posfg)
##        if cc <> 0:
##            s.frictionmath(0)
##            s.frictionmath(1)
##            dx = 1
##            dy = 1
##            if s.speed[0] <> 0:
##                dx = int(s.speed[0] / abs(s.speed[0]))
##            if s.speed[1] <> 0:
##                dy = int(s.speed[1] / abs(s.speed[1]))
##            for a in range(4):
##                cd = s.paralayer.groundmask.overlap_area(s.mask, (posfg[0], posfg[1] + dy))
##                #if s.submerged == False and a == 0 and s.landslip == True:
##                #    pass
##                if s.landslip == True and abs(s.speed[1]) > abs(s.speed[0]) and a==0:
##                    pass
##                elif cc > cd:
##                    s.pos[1] += dy#round(s.pos[1] + dy + 0.5) - 0.5# * 0.5
##                    if s.speed[1] * dy < 0:
##                        s.speed[1] = 0
##                    #s.frictionmath(0)
##                    s.collflags[2 + int(dy)] = True
##                    cc = cd
##                else:
##                    cd = s.paralayer.groundmask.overlap_area(s.mask, (posfg[0], posfg[1] - dy))
##                    if cc > cd:
##                        s.pos[1] -= dy#round(s.pos[1] - dy + 0.5) - 0.5# * 0.5
##                        if s.speed[1] * dy > 0:
##                            s.speed[1] = 0
##                        #s.frictionmath(0)
##                        s.collflags[2 - int(dy)] = True
##                        cc = cd
##                if cc == 0:
##                    break
##                cd = s.paralayer.groundmask.overlap_area(s.mask, (posfg[0] + dx, posfg[1]))
##                if cc > cd:
##                    s.pos[0] += dx#round(s.pos[0] + dx + 0.5) - 0.5# * 0.5
##                    if s.speed[0] * dx < 0:
##                        s.speed[0] = 0
##                    #s.frictionmath(1)
##                    s.collflags[1 + int(dx)] = True
##                    cc = cd
##                else:
##                    cd = s.paralayer.groundmask.overlap_area(s.mask, (posfg[0] - dx, posfg[1]))
##                    if cc > cd:
##                        s.pos[0] -= dx#round(s.pos[0] - dx + 0.5) - 0.5# * 0.5
##                        if s.speed[0] * dx > 0:
##                            s.speed[0] = 0
##                        #s.frictionmath(1)
##                        s.collflags[1 - int(dx)] = True
##                        cc = cd
##                if cc == 0:
##                    break
    def submergedcheck(s):
        #s.submerged = False
        splashvol = abs(s.speed[1]) * s.density
        if s.paralayer.waveform <> None and s.pos[1] + s.rect.h / 2 > s.paralayer.waveform(s.pos[0] + s.rect.w / 2, s.paralayer.framecounter) + env.waterlevel:
            if s.submerged == False:
                if splashvol > 0.1:
                    playsound("waterenter.wav", splashvol, s.pos)
                s.submerged = True
            s.speed[1] -= gravity / s.density
            s.speed[0] -= s.speed[0] * s.drag / s.weight
            s.speed[1] -= s.speed[1] * s.drag / s.weight
            #drag should be exponential, not linear, but exponential causes bugs at reasonable framerates.
        elif s.submerged == True:
            if splashvol > 0.1:
                playsound("waterexit.wav", splashvol, s.pos)
            s.submerged = False
    def update(s):
        #s.collflags = [0, 0, 0, 0] #right, down, left, up?
        s.speed[1] += gravity
        s.submergedcheck()
        s.mask = pygame.mask.from_surface(s.image)
        s.pos[0] += s.speed[0]
        s.pos[1] += s.speed[1]
        if s.paralayer.mask <> None:
            s.collphysics(s.paralayer)
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        if s.stuntimer > 0:
            s.stuntimer -= 1
        if s.submerged == True and Bubbling.has(s) and random.random() < 0.005:
            maxsize = 4
            if s.weight < 13:
                maxsize = 1
            elif s.weight < 50:
                maxsize = s.weight * 0.08
            Bubble([s.pos[0] + random.randrange(s.rect.width), s.pos[1]], s.paralayer, maxsize = maxsize)
    def dmgdealt(s, victim):
        if pygame.sprite.collide_mask(victim, s) <> None:
            return s.harm
        return 0
    def stung(s):
        if s.stuntimer <= 0:
            s.stuntimer += s.stuntime

class Inert(Obj):
    def __init__(s, pos, density, weight, sheet, paralayer, groups = []):
        drag = weight / 10.0 / density
        Obj.__init__(s, pos, density, weight, drag, sheet, paralayer, groups)
        s.image = s.sheet

class Jellyfish(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.02, 65, 5, "jellyfish.png", paralayer, groups + [Grabbables, Bubbling])
        s.stage = 1
        s.counter = 0
        s.sheetoffset = random.choice([7, 14, 21, 28, 35, 42, 49])
        s.dfltimg = s.sheet.subsurface((0, s.sheetoffset, 7, 5))
        s.upseq = [s.sheet.subsurface((x, s.sheetoffset, 7, 5)) for x in (7, 14, 0)]
        s.image = s.dfltimg
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.acc = [0, 0]
        s.tlength = random.randrange(4, 8)
##        s.tpos = [0, s.tlength]
##        s.tcolour = s.image.get_at((2, 4))
        s.grabbed = None
        s.tinit()
    def update(s):
        s.counter -= 1
        if s.speed[1] < 0:
            if s.stage == 1 and s.counter <= 0:
                s.stage = 2
                s.counter = 10
                s.image = s.upseq[0]
            elif s.stage == 2 and s.counter <= 0:
                s.stage = 3
                s.counter = 10
                s.image = s.upseq[1]
            elif s.stage == 3 and s.counter <= 0:
                s.stage = 1
                s.counter = 20
                s.image = s.upseq[2]
        elif s.stage <> 1:
            s.stage = 1
            s.image = s.dfltimg
        s.acc[0] += random.uniform(-0.002, 0.002)
        s.acc[1] += random.uniform(-0.002, 0.002)
        if s.acc[0] > 0.02 or s.collflags[2] == True:
            s.acc[0] = 0.02
        elif s.acc[0] < -0.02 or s.collflags[0] == True:
            s.acc[0] = -0.02
        if s.acc[1] > 0.02 or s.collflags[3] == True:
            s.acc[1] = 0.02
        elif s.acc[1] < -0.02 or s.collflags[1] == True:
            s.acc[1] = -0.02
        if s.submerged == False:
            s.acc[1] = 0
        else:
            s.speed[0] += s.acc[0]
            s.speed[1] += s.acc[1]
##        s.tpos[0] -= s.speed[0]
##        s.tpos[0] *= 0.975
        Obj.update(s)
        s.tupdate()
        s.collflags = [0, 0, 0, 0]
    def draw(s, surface, screenpos):
        s.tdraw(surface, screenpos)
        surface.blit(s.image, screenpos)
##        pygame.draw.line(surface, s.tcolour, (screenpos[0] + 2, screenpos[1] + 4), (screenpos[0] + 2 + s.tpos[0], screenpos[1] + 4 + s.tpos[1] + s.tpos[0] / 8))
##        pygame.draw.line(surface, s.tcolour, (screenpos[0] + 4, screenpos[1] + 4), (screenpos[0] + 4 + s.tpos[0], screenpos[1] + 4 + s.tpos[1] - s.tpos[0] / 8))
    def tinit(s):
        s.tlist = [[s.pos[0] + 3, s.pos[1] + 4 + a] for a in range(s.tlength)]
        s.tcolour = s.image.get_at((2, 4))
    def tupdate(s):
        if len(s.tlist) < int(s.tlength):
            s.tlist[:0] = [[0, 0]]
        elif len(s.tlist) > int(s.tlength):
            s.tlist.pop(0)
        anchor = [s.pos[0] + 3.5, s.pos[1] + 4.5]
        for a in range(len(s.tlist)):
            s.tlist[a][1] += gravity * 10
        for z in range(2):
            for a in range(len(s.tlist)):
                if a == 0:
                    #s.tlist[a][0] = s.pos[0] + 3.5
                    #s.tlist[a][1] = s.pos[1] + 4.5
                    s.tlist[a] = anchor
                else:
                    q = 5
                    while get_at_tol(s.paralayer.mask, (s.tlist[a][0], s.tlist[a][1]), s.paralayer.pos) and q <> 0:
                        if get_at_tol(s.paralayer.mask, (s.tlist[a][0] - 1, s.tlist[a][1]), s.paralayer.pos) == False:
                            s.tlist[a][0] -= 0.1
                        elif get_at_tol(s.paralayer.mask, (s.tlist[a][0] + 1, s.tlist[a][1]), s.paralayer.pos) == False:
                            s.tlist[a][0] += 0.1
                        elif get_at_tol(s.paralayer.mask, (s.tlist[a][0], s.tlist[a][1] - 1), s.paralayer.pos) == False:
                            s.tlist[a][1] -= 0.1
                        q -= 1
                    px = s.tlist[a - 1][0]
                    py = s.tlist[a - 1][1]
                    if math.hypot(s.tlist[a][0] - px, s.tlist[a][1] - py) > 1:
                        t = math.atan2(s.tlist[a][0] - px, s.tlist[a][1] - py)
                        s.tlist[a][0] = math.sin(t) + px
                        s.tlist[a][1] = math.cos(t) + py
            if s.grabbed <> None:
                anchor = [s.grabbed.pos[0] + s.grabbed.rect.w / 2, s.grabbed.pos[1] + s.grabbed.rect.h / 2]
                s.tlist.reverse()
            else:
                break
        s.tlist[0] = [s.pos[0] + 3.5, s.pos[1] + 4.5]
    def tdraw(s, surface, screenpos):
        pygame.draw.lines(surface, s.tcolour, False, [[x + screenpos[0] - s.pos[0] + 1, y + screenpos[1] - s.pos[1]] for [x, y] in s.tlist])
        pygame.draw.lines(surface, s.tcolour, False, [[x + screenpos[0] - s.pos[0] - 1, y + screenpos[1] - s.pos[1]] for [x, y] in s.tlist])

class Player(Jellyfish):
    def __init__(s, pos, keyset, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.1, 65, 5, "jellyfish.png", paralayer, groups + [PlayerGroup, Bubbling])
        s.paralayer.change_layer(s, 1)
        s.upseq = [s.sheet.subsurface((x, 0, 7, 5)) for x in (7, 14, 0, 0)]
        s.fatseq = [s.sheet.subsurface((x, 0, 7, 5)) for x in (21, 28, 35)]
        s.image = s.upseq[2]
        s.stage = 1
        #s.image = s.sheet.subsurface((0, 0, 7, 5))
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.keyset = keyset
        #s.counter = 0
        s.health = 8
        s.fullness = 0
        s.shield = 0
        s.tlength = 6
        s.tinit()
        s.grabbing = False
        s.grabbed = None
        s.fatcounter = 0
        s.scoregained = 0
    def control(s, keys):
        #s.counter -= 1
        if s.fullness > 4:
            if s.fatcounter > 0:
                s.fatcounter -= 1
                s.image = s.fatseq[1]
            else:
                s.image = s.fatseq[2]
        elif s.fatcounter > 0:
            s.fatcounter -= 1
            s.image = s.fatseq[0]
        elif keys[s.keyset["UP"]] or s.speed[1] < 0:
            s.framecounter(10, s.upseq)
        else:
            s.image = s.upseq[2]
        if s.submerged == True:
            if keys[s.keyset["UP"]]:
                s.speed[1] -= 0.04
            if keys[s.keyset["DOWN"]]:
                s.speed[1] += 0.04
            if keys[s.keyset["LEFT"]]:
                s.speed[0] -= 0.04
            if keys[s.keyset["RIGHT"]]:
                s.speed[0] += 0.04
        if keys[s.keyset["B1"]]:
            if s.tlength > 3:
                s.tlength -= 0.1
        elif s.tlength < 10:
            s.tlength += 0.1
        if keys[s.keyset["B2"]]:
            s.grabbing = True
        else:
            s.grabbing = False
            s.grabbed = None
        if Grabbables.has(s.grabbed) == False:
            s.grabbed = None
        if s.grabbed <> False and s.tlength <= 3 and Edibles.has(s.grabbed) and s.fullness + s.grabbed.bulk <= 8:
            if s.health < 8:
                s.health += s.grabbed.nutri
            s.fullness += s.grabbed.bulk
            s.grabbed.kill()
            s.grabbed = None
            s.fatcounter = 10
            playsound("yomp2.wav")
        s.camerarel[0] += s.speed[0] / 2
        s.camerarel[1] += s.speed[1] / 2
        if s.camerarel[0] > 6:
            s.camerarel[0] = 6
        elif s.camerarel[0] < -6:
            s.camerarel[0] = -6
        if s.camerarel[1] > 6:
            s.camerarel[1] = 6
        elif s.camerarel[1] < -6:
            s.camerarel[1] = -6
        #s.camerarel[0] *= 0.925
        #s.camerarel[1] *= 0.925
        collchecklist = Stingables.sprites()
        if s.grabbing == True and s.grabbed == None:
            collchecklist += Grabbables.sprites()
        for sprite in set(collchecklist):
            if sprite.rect.collidepoint(s.tlist[-1]) == True:
                if get_at_tol(sprite.mask, (s.tlist[-1][0] - sprite.pos[0], s.tlist[-1][1] - sprite.pos[1])) == True:
                    sprite.stung()
                    if s.grabbing == True and Grabbables.has(sprite) and s.grabbed == None:
                        s.grabbed = sprite
    def update(s):
        Obj.update(s)
        if s.grabbed <> None:
            g = s.grabbed
            gcenter = [g.pos[0] + g.rect.w / 2, g.pos[1] + g.rect.h / 2]
            stroot = [s.pos[0] + 3.5, s.pos[1] + 4.5]
            d = math.hypot(gcenter[0] - (stroot[0]), gcenter[1] - (stroot[1]))
            maxdist = s.tlength
            if d > maxdist:
                spro = float(s.weight) / (s.weight + g.weight)
                gpro = float(g.weight) / (s.weight + g.weight)
                #spro = 1
                #gpro = 0
                t = math.atan2(gcenter[0] - (stroot[0]), gcenter[1] - (stroot[1]))
                #g.pos[0] = g.pos[0] * gpro + (math.sin(t) * maxdist + s.pos[0]) * spro
                #g.pos[1] = g.pos[1] * gpro + (math.cos(t) * maxdist + s.pos[1]) * spro
                g.speed[0] += gcenter[0] * gpro + (math.sin(t) * maxdist + stroot[0]) * spro - gcenter[0]
                g.speed[1] += gcenter[1] * gpro + (math.cos(t) * maxdist + stroot[1]) * spro - gcenter[1]
                t += math.pi
                s.speed[0] += stroot[0] * spro + (math.sin(t) * maxdist + gcenter[0]) * gpro - stroot[0]
                s.speed[1] += stroot[1] * spro + (math.cos(t) * maxdist + gcenter[1]) * gpro - stroot[1]
            #g.pos = list(s.tlist[-1])
        s.tupdate()
        #print s.speed
        if s.shield > 0:
            s.shield -= 1
        if s.fullness > 0:
            s.fullness -= 0.002
        if s.health > 8:
            s.health = 8
    def draw(s, surface, screenpos):
        if s.shield%2 == 0:
            s.tdraw(surface, screenpos)
            surface.blit(s.image, screenpos)
    def dmgcheck(s, sprites):
        if s.shield <= 0:
            for sprite in sprites:
                dmg = sprite.dmgdealt(s)
                s.health -= dmg
                if dmg > 0:
                    s.shield = 80
                    s.speed = [-s.speed[0], -s.speed[1]]
                    playsound("hurt3.wav")
    def bonuscheck(s, sprites):
        for sprite in sprites:
            if pygame.sprite.collide_mask(sprite, s) <> None:
                get_progstate()["bonusmeter"] += 1
                get_progstate()["score"] += 1
                s.scoregained += 1
                sprite.kill()
                playsound("bonus.wav")
                if get_progstate()["bonusmeter"] >= 4:
                    get_progstate()["lives"] += 1
                    get_progstate()["bonusmeter"] = 0
                    LifeFloater([s.pos[0] - 2, s.pos[1]], s.paralayer)
                    playsound("1up2.wav")
                    

class Fish(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.0, 10, 1, "fish.png", paralayer, groups + [Stingables, Grabbables, Edibles, Bubbling])
        offset = random.choice((0, 5, 10, 15, 20))
        s.omniseq = [s.sheet.subsurface((x, offset, 5, 5)) for x in range(0, 30, 5)]
        s.stunseq = [s.sheet.subsurface((x, offset, 5, 5)) for x in (30, 35)]
        s.image = s.omniseq[0]
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.stuntime = 400
        s.nutri = 1
        s.bulk = 1
    def update(s):
        Obj.update(s)
        if s.stuntimer > 0:
            if s.stuntimer > 360:
                if s.speed[0] >= 0:
                    s.framecounter(5, [s.omniseq[a] for a in (0, 1, 0, 2)])
                else:
                    s.framecounter(5, [s.omniseq[a] for a in (-1, -2, -1, -3)])
            elif s.speed[0] >= 0:
                s.image = s.stunseq[0]
            else:
                s.image = s.stunseq[1]
            s.speed[1] -= 0.002
        elif random.random() < 0.05:
            jerkspeed = random.uniform(0, 0.5)
            jerk = (random.choice((-1, 1)) * jerkspeed, random.uniform(-1, 1) * jerkspeed)
            s.speed[0] += jerk[0]
            s.speed[1] += jerk[1]
            if s.speed[1] > abs(s.speed[0]) / 2:
                o = 2
            elif s.speed[1] < -abs(s.speed[0]) / 2:
                o = 1
            else:
                o = 0
            if s.speed[0] >= 0:
                s.image = s.omniseq[o]
            else:
                s.image = s.omniseq[-1 - o]
class SaberFish(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.0, 30, 1, "saberfish.png", paralayer, groups + [Stingables, Grabbables, Edibles, Harmfulls, Bubbling])
        s.leftseq = [s.sheet.subsurface((x, 0, 8, 4)) for x in (0, 8)]
        s.rightseq = [s.sheet.subsurface((x, 4, 8, 4)) for x in (0, 8)]
        s.stunleftseq = [s.sheet.subsurface((x, 0, 8, 4)) for x in (16, 24)]
        s.stunrightseq = [s.sheet.subsurface((x, 4, 8, 4)) for x in (16, 24)]
        s.image = s.rightseq[0]
        s.currentseq = s.rightseq
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.stuntime = 400
        s.harm = 1
        s.nutri = 1
        s.bulk = 1.5
    def update(s):
        Obj.update(s)
        if s.stuntimer > 0:
            if s.stuntimer > 380:
                if s.speed[0] >= 0:
                    s.image = s.stunrightseq[0]
                else:
                    s.image = s.stunleftseq[0]
            elif s.speed[0] >= 0:
                s.image = s.stunrightseq[1]
            else:
                s.image = s.stunleftseq[1]
            s.speed[1] -= 0.002
        else: #s.submerged == True:
            if random.random() < 0.05:
                jerkspeed = random.uniform(0, 0.25)
                jerk = (random.choice((-1, 1)) * jerkspeed, random.uniform(-1, 1) * jerkspeed)
                s.speed[0] += jerk[0]
                s.speed[1] += jerk[1]
                if s.speed[0] > 0:
                    s.currentseq = s.rightseq
                else:
                    s.currentseq = s.leftseq
            s.framecounter(15, s.currentseq)
    def dmgdealt(s, victim):
        if s.stuntimer <= 0:
            return Obj.dmgdealt(s, victim)
        return 0

class Frog(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.4, 20, 1, "frog.png", paralayer, groups + [Stingables, Grabbables, Edibles, Bubbling])
        s.dfltimgs = [s.sheet.subsurface((0, z, 7, 7)) for z in (7, 0)]
        s.jumpseqs = [[s.sheet.subsurface((x, z, 7, 7)) for x in (7, 14)] for z in [7, 0]]
        s.swimupseqs = [[s.sheet.subsurface((x, z, 7, 7)) for x in (21, 28)] for z in [7, 0]]
        s.stunseqs = [[s.sheet.subsurface((x, z, 7, 7)) for x in (35, 42)] for z in [7, 0]]
        s.image = s.dfltimgs[1]
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.dir = 1
        s.stuntime = 400
        s.nutri = 1
        s.bulk = 1
        s.landslip = False
        s.airborn = True
        s.upswim = False
    def update(s):
        Obj.update(s)
        if s.stuntimer > 0:
            if s.stuntimer > 360:
                s.image = s.stunseqs[s.dir][0]
            else:
                s.image = s.stunseqs[s.dir][1]
        else:
            if s.collflags[1] == True and s.speed[1] >= 0:
                s.airborn = False
                s.image = s.dfltimgs[s.dir]
            if s.airborn == False:
                if random.random() < 0.05:
                    if random.random() < 0.25:
                        s.dir = [1, 0][s.dir]
                    power = random.uniform(0.5, 1)
                    s.speed[0] = power * (-1, 1)[s.dir]
                    s.speed[1] = -power
                    s.image = s.jumpseqs[s.dir][0]
                    s.airborn = True
                elif random.random() < 0.01:
                    s.dir = [1, 0][s.dir]
                    s.upswim = True
                    s.airborn = True
            if s.upswim == True:
                if s.collflags[3] == True:
                    s.upswim = False
                if s.submerged == True:
                    s.framecounter(15, s.swimupseqs[s.dir])
                    if s.dir == 0:
                        s.speed[0] -= 0.05
                    else:
                        s.speed[0] += 0.05
                    s.speed[1] -= 0.05
                else:
##                    spdboost = random.uniform(0, 0.5)
##                    if s.dir == 0:
##                        s.speed[0] -= spdboost
##                    else:
##                        s.speed[0] += spdboost
##                    s.speed[1] -= spdboost
                    s.image = s.jumpseqs[s.dir][0]
                    s.upswim = False
            if s.airborn == True and s.speed[1] > 0:
                s.image = s.jumpseqs[s.dir][1]
                if s.submerged == True:
                    if s.dir == 0:
                        s.speed[0] -= 0.01
                    else:
                        s.speed[0] += 0.01
        s.collflags = [0, 0, 0, 0]

class Crab(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.4, 100, 5, "crab.png", paralayer, groups + [Harmfulls, Stingables, Grabbables, Bubbling])
        #s.stage = 1
        #s.counter = 0
        #s.sheetoffset = [0, 6]
        #s.image = s.sheet.subsurface((s.sheetoffset[0], s.sheetoffset[1], 10, 6))
        s.dfltseq = [s.sheet.subsurface((x, 0, 10, 6)) for x in (0, 10, 20, 30, 40)]
        s.moverightseq = [s.sheet.subsurface((x, 0, 10, 6)) for x in (40, 50, 60)]
        s.moveleftseq = s.moverightseq[:]
        s.moveleftseq.reverse()
        s.jumpseq = [s.sheet.subsurface((x, 0, 10, 6)) for x in (70, 80, 90, 100)]
        s.shockseq = [s.sheet.subsurface((x, 0, 10, 6)) for x in (110, 120)]
        s.stunnedseq = [s.sheet.subsurface((130, 0, 10, 6))]
        s.image = s.dfltseq[2]
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.dir = 0
        s.harm = 1
        s.jumping = False
        s.jumptimer = 0
        s.stuntime = 400
        s.nutri = 1
        s.bulk = 2
        s.landslip = False
    def update(s):
        Obj.update(s)
        #leg1 = s.paralayer.groundmask.
##        if random.random() < 0.01 and s.dir <> -1:
##            s.dir -= 1
##        if random.random() < 0.01 and s.dir <> 1:
##            s.dir += 1
##        if s.dir == -1:
##            s.speed[0] -= 0.05
##        if s.dir == 1:
##            s.speed[0] += 0.05
        if s.stuntimer > 0:
            if s.stuntimer > 360:
                s.framecounter(5, s.shockseq)
            elif s.stuntimer == 360:
                s.remove(Harmfulls)
                s.add(Edibles)
                s.image = s.stunnedseq[0]
            elif s.stuntimer == 1:
                s.add(Harmfulls)
                s.remove(Edibles)
        elif s.jumping == True:
            s.framecounter(5, s.jumpseq)
            if s.collflags[1] == True:
                s.jumping = False
                s.jumptimer = 20
                s.dir = random.choice([-0.2, 0, 0, 0.2])
        else:
            if random.random() < 0.02:
                s.dir = random.choice([-0.2, 0, 0, 0.2])
            if s.dir > 0:
                s.framecounter(10, s.moverightseq)
            elif s.dir < 0:
                s.framecounter(10, s.moveleftseq)
            else:
                if random.random() < 0.05:
                    s.image = random.choice(s.dfltseq)
            if get_at_tol(s.paralayer.mask, (s.pos[0]-1, s.pos[1]+3), s.paralayer.pos):
                s.dir = 0.2
            if get_at_tol(s.paralayer.mask, (s.pos[0]+10, s.pos[1]+3), s.paralayer.pos):
                s.dir = -0.2
            if s.collflags[1] == True:
                s.speed[0] += s.dir
            if s.collflags[1] == True and PlayerGroup.sprite <> None and s.jumptimer <= 0:
                if pygame.Rect(s.pos[0] - 3, s.pos[1] -10, 16, 10).colliderect(PlayerGroup.sprite.rect):
                    s.jumping = True
                    s.speed[1] -= 0.75
        if s.jumptimer > 0:
            s.jumptimer -= 1
        s.collflags = [0, 0, 0, 0]
    def stung(s):
        if s.stuntimer <= 0:
            s.stuntimer += s.stuntime
            s.framecount = 0
    def dmgdealt(s, victim):
        if s.stuntimer <= 0 or s.stuntimer > 160:
            return Obj.dmgdealt(s, victim)
        return 0

class MadUrch(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.1, 25, 1, "madurch.png", paralayer, groups + [Harmfulls, Stingables, Grabbables, Bubbling])
        s.moveseq = [s.sheet.subsurface(x, 0, 5, 5) for x in (0, 5, 0, 10)]
        s.image = s.moveseq[0]
        s.dir = 0
        s.harm = 1
        s.stuntime = 200
        s.landslip = False
        s.friction = 1
    def update(s):
        Obj.update(s)
        if s.stuntimer > 0:
            if s.stuntimer > 120:
                s.framecounter(5, s.moveseq)
            else:
                s.dir = 0
        elif random.random() < 0.005:
            s.dir = random.choice((-0.075, 0, 0.075))
        if s.dir <> 0:
            if s.collflags[1] == True:
                s.speed[0] += s.dir
            s.framecounter(20, s.moveseq)
        else:
            s.image = s.moveseq[0]
        s.collflags = [0, 0, 0, 0]
    def stung(s):
        if s.stuntimer <= 0:
            s.stuntimer += s.stuntime
            s.framecount = 0

class Clam(Obj):
    def __init__(s, pos, paralayer = None, groups = [], childtype = "pearl"):
        Obj.__init__(s, pos, 1.5, 25, 1, "clam.png", paralayer, groups + [Stingables])
        s.paralayer.change_layer(s, -1.2)
        s.seq = [s.sheet.subsurface(x, 0, 5, 7) for x in (0, 5)]
        s.image = s.seq[0]
        s.counter = random.randrange(200, 400)
        s.stuntime = 400
        s.harm = 2
        s.harmtimer = 0
        s.childtype = childtype
        s.child = None
        s.haschild = True
        s.childrel = [0, 0]
    def openclam(s):
        s.image = s.seq[1]
        if s.haschild == True:
            if s.childtype == "bonus":
                s.childrel = [1, 1]
                s.child = Bonus([s.pos[0] + 1, s.pos[1] + 1], s.paralayer)
            else:
                s.childrel = [2, 4]
                s.child = Pearl([s.pos[0] + 2, s.pos[1] + 4], s.paralayer)
            s.paralayer.change_layer(s.child, -1.1)
    def shutclam(s):
        s.add(Harmfulls)
        s.image = s.seq[0]
        s.harmtimer = 3
        if Objs.has(s.child) == False:
            s.haschild = False
        if s.child <> None:
            s.child.kill()
            s.child = None
        playsound("clamsnap.wav", pos = s.pos)
    def update(s):
        Obj.update(s)
        if s.stuntimer > 0:
            if s.stuntimer == 1:
                s.openclam()
        else:
            s.counter -= 1
            if s.counter == 200:
                s.openclam()
            if s.counter <= 0:
                s.shutclam()
                s.counter = 400
        if s.harmtimer > 0:
            s.harmtimer -= 1
        if s.harmtimer == 1:
            s.remove(Harmfulls)
        if Objs.has(s.child) == True:
            s.child.pos[0] = s.pos[0] + s.childrel[0]
            s.child.pos[1] = s.pos[1] + s.childrel[1]
    def stung(s):
        if s.stuntimer <= 0 and s.counter < 200:
            s.shutclam()
            s.stuntimer += s.stuntime

class Pearl(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 2, 5, 0.25, "bonus.png", paralayer, groups + [Harmfulls])
        s.mask = pygame.mask.Mask((1, 1))
        s.mask.fill()
        s.rect = pygame.rect.Rect(s.pos, (1, 1))
        s.colour = random.choice([(255, 255, 128), (200, 255, 255)])
        s.harm = -3
    def update(Obj):
        pass
    def draw(s, surface, screenpos):
        surface.set_at(screenpos, s.colour)
    def dmgdealt(s, victim):
        if pygame.sprite.collide_mask(victim, s) <> None:
            s.kill()
            return s.harm
        return 0

class Bonus(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 19, 150, 1, "bonus.png", paralayer, groups + [Bonusses])
        s.seq = [s.sheet.subsurface(x, 0, 4, 4) for x in (0, 4, 8, 12, 16, 16)]
        s.image = s.seq[0]
        s.mask = pygame.mask.from_surface(s.image, 1)
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.counter = random.randrange(49, 200)
        QuasiBodies.remove(s)
    def update(s):
        #Obj.update(s)
        s.counter -= 1
        if s.counter <= 0:
            s.counter = 200
            s.image = s.seq[0]
        if s.counter <= 48:
            s.framecounter(8, s.seq)

class Rock(Obj):
    def __init__(s, pos, paralayer = None, groups = [], size = None):
        if size == None:
            size = random.randrange(5)
        Obj.__init__(s, pos, 2, 65 * (size + 1), 1 * (size + 1), "rocks.png", paralayer, groups + [Grabbables, HardBodies])
        args = ((1, 1, 4, 4), (6, 1, 6, 5), (13, 1, 8, 7), (22, 1, 8, 9), (31, 1, 14, 10))[size]
        s.image = s.sheet.subsurface(*args)
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        s.landslip = False

class LillyPad(Obj):
    def __init__(s, pos, cpos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 0.5, 5, 1, "lillypad.png", paralayer, groups)
        s.image = s.sheet
        s.cpos = cpos
        QuasiBodies.remove(s)
    def draw(s, surface, screenpos):
        pygame.draw.line(surface, (0, 128, 0), (screenpos[0] + 3, screenpos[1] + 3), (screenpos[0] + s.cpos[0] - s.pos[0], screenpos[1] + s.cpos[1] - s.pos[1]))
        Obj.draw(s, surface, screenpos)

class Bubble(Static):
    def __init__(s, pos, paralayer = None, groups = [], size = None, maxsize = 4):
        #Obj.__init__(s, pos, 0.5, 5, 1, "bubbles.png", paralayer, groups)
        pygame.sprite.Sprite.__init__(s, groups + [Objs, paralayer])
        s.pos = pos
        s.sheet = get_image("bubbles.png", 1)
        s.paralayer = paralayer
        s.paralayer.change_layer(s, -3)
        if size == None:
            size = int(maxsize) - int(math.log(random.randrange(1, 2**(int(maxsize + 1)) - 1), 2))
        s.pos[0] -= (size + 2) / 2
        s.image = s.sheet.subsurface(size*(3 + size) / 2, 0, size + 2, size + 2)
        s.image.set_alpha(200)
        s.rect = pygame.rect.Rect(s.pos, s.image.get_size())
        #s.mask = pygame.mask.from_surface(s.image, 1)
    def update(s):
        #Obj.update(s)
        #s.speed[1] -= gravity
        s.pos[1] -= 0.2
        s.submerged = False
        if s.paralayer.waveform <> None and s.pos[1] + s.rect.h / 2 > s.paralayer.waveform(s.pos[0] + s.rect.w / 2, s.paralayer.framecounter) + env.waterlevel:
            s.submerged = True
        #s.submergedcheck()
        if s.submerged == False or random.random() < 0.005:
            s.kill()
    def draw(s, surface, screenpos):
        surface.blit(s.image, screenpos)

class LifeFloater(Static):
    def __init__(s, pos, paralayer = None, groups = []):
        Static.__init__(s, pos, "1up.png", (10, 6), paralayer, groups = groups)
        s.deathtimer = 127
    def update(s):
        Static.update(s)
        s.pos[1] -= 0.1
        s.deathtimer -= 1
        s.image.set_alpha(int(s.deathtimer * 2))
        if s.deathtimer == 0:
            s.kill()

class LiftCage(Obj):
    def __init__(s, pos, paralayer = None, groups = []):
        Obj.__init__(s, pos, 1.5, 100, 5, "1-2cage.png", paralayer, groups = groups + [HardBodies])
        s.paralayer.change_layer(s, 2)
        s.image = s.sheet
        s.initpos = tuple(s.pos)
        s.stuck = 1
        s.child = None
        #s.child = Static([s.pos[0] + 8, s.pos[1] - 32], "1-2cagerope.png", [4, 36], s.paralayer)
        #s.childrelpos = [8, -32]
    def update(s):
        Obj.update(s)
        s.pos[0] = s.initpos[0]
        s.speed[0] = 0
        if s.stuck == True:
            if s.pos[1] - s.initpos[1] < 2:
                s.speed[1] -= 0.02
            elif s.pos[1] - s.initpos[1] > 8:
                s.stuck = False
                s.child = Static([s.pos[0] + 1, s.pos[1] - 16], "1-2cageropewhip.png", [11, 26], s.paralayer, animspeed = 1)
                s.paralayer.change_layer(s.child, 2.1)
                #s.childrelpos = [8, -16]
                playsound("cageropesnap.wav")
            else:
                s.speed[1] -= 0.04
        if s.child <> None:
            s.child.pos[1] = s.pos[1] - 16
            if s.child.framenum == 16:
                s.child.kill()
                s.child = None
    def draw(s, surface, screenpos):
        Obj.draw(s, surface, screenpos)
        if s.stuck == True:
            surface.blit(get_image("1-2cagerope.png", 1), [screenpos[0] + 8, screenpos[1] - 16])
        surface.blit(get_image("1-2cagebars.png", 1), [screenpos[0], screenpos[1] + 7])
        if s.stuck == True:
            pygame.draw.line(surface, (128, 64, 0), [screenpos[0] + 8, screenpos[1] - 16], [screenpos[0] + 8, -1])
        if s.stuck == True or s.child <> None:
            pygame.draw.line(surface, (128, 64, 0), [screenpos[0] + 11, screenpos[1] - 16], [screenpos[0] + 11, -1])

class Enviroment:
    def init(s, paralayers, waterlevel, watercolour, waveform, boundries, wincond = None):
        s.paralayers = paralayers
        s.waterlevel = waterlevel
        if len(watercolour) == 3:
            watercolour.append(63)
        s.watercolour = watercolour
        s.waveform = waveform
        s.boundries = boundries
        s.wincond = wincond
    def kill(s):
        for sprite in Objs.sprites():
            sprite.kill()
env = Enviroment()

##def wavetopgen(waveform, frames, para):
##    pointlist = []
##    for x in range(0, int((env.boundries[0] - screensize[0]) * para + screensize[0] + 1), 2):
##        y = round(waveform(x / para, frames) * para + env.waterlevel)
##        pointlist += [[x, y]]
##    return pointlist

def drawwater(surface, waveform, campos, frames, para):
    pointlist = []
    for a in range(screensize[0] / 2 + 1):
        x = a * 2 / para + (campos[0] + screensize[0] / 2) - screensize[0] / 2 / para
        y = round((waveform(x, frames) - int(campos[1]) + env.waterlevel - screensize[1] / 2) * para + screensize[1] / 2)
        pointlist += [[a * 2, y]]
    pointlist += [[screensize[0], screensize[1] + 1],[0, screensize[1] + 1]]
    water = pygame.surface.Surface(screensize)#.convert_alpha()
    water.fill((255, 255, 255))
    colour = list(env.watercolour[:3])
##    for i in range(3):
##        if campos[1] - env.waterlevel > 0:
##            colour[i] -= campos[1] - env.waterlevel
##        if colour[i] < 0:
##            colour[i] = 0
##        if colour[i] > 255:
##            colour[i] = 255
    alpha = env.watercolour[3]
    if alpha - (campos[1]) / 2 < 0:
        alpha1 = 0
        alpha2 = alpha * 3
    if alpha + (campos[1]) > 255:
        alpha1 = 255 - alpha
        alpha2 = 255
    else:#if campos[1] - env.waterlevel > 0:
        alpha1 = alpha - (campos[1] - env.waterlevel) / 2
        alpha2 = alpha + (campos[1] - env.waterlevel)
    pygame.draw.polygon(water, colour, pointlist)
    water.set_colorkey((255, 255, 255))
    water.set_alpha(alpha1)
    surface.blit(water, (0, 0))
    water.set_alpha(alpha2)
    water.blit(surface, (0, 0), special_flags = BLEND_MULT)
    surface.blit(water, (0, 0))
    return surface

class ParaLayer(pygame.sprite.LayeredUpdates):
    def __init__(s, parallax = 1, image = None, mask = None, water = False, waveform = None, sprites = [], pos = (0, 0)):
        pygame.sprite.LayeredUpdates.__init__(s, sprites)
        s.image = image
        if image <> None:
            s.image = get_image(image, 1)
        if mask <> None:
            s.mask = pygame.mask.from_surface(get_image(mask, 1))
        else:
            s.mask = None
        #s.foreground = foreground
        #if foreground <> None:
        #    s.foreground = get_image(foreground, 1)
        s.para = parallax
        s.water = water
        s.waveform = waveform
        s.framecounter = 0
        s.pos = pos
        for sprite in sprites:
            sprite.paralayer = s
    def draw(s, surface, campos):
        s.framecounter += 1
        if s.image <> None:
            x = (-campos[0]) * s.para
            y = (-campos[1]) * s.para
            surface.blit(s.image, (x,y))
        for spr in s.sprites():
            x = (int(spr.pos[0]) - campos[0]) * s.para
            y = (int(spr.pos[1]) - campos[1]) * s.para
            spr.draw(surface, (x, y))
        #if s.foreground <> None:
        #    x = (-campos[0]) * s.para
        #    y = (-campos[1]) * s.para
        #    surface.blit(s.foreground, (x,y))
        if s.waveform == None:
            s.waveform = env.waveform
        if s.water == True:
            drawwater(surface, s.waveform, campos, s.framecounter, s.para)
        return surface
